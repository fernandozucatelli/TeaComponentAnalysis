%% fc_main_21_table_style_intermediate_tex
%%%%%%%%%%%%%
% help fc_main_21_table_style_intermediate_tex
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to write a LaTeX table from the intermediate table style data
%%%%%%%%%%%%%
% version 01: 2020-01-01 -- Creation (ISO8601)
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_21_table_style_intermediate_tex(excel_data_folder, tex_file_name, ...
        filter, file_to_load_sample, caption_name, label_name)
%% File names
tex_file_name_path = tex_file_name{1};
tex_radical = 'input_longtab';
tex_file_name_1 = sprintf('%s/%s_%s',tex_file_name_path,tex_radical,tex_file_name{2});
tex_file_name_2 = sprintf('%s/%s_%s',tex_file_name_path,tex_radical,tex_file_name{3});
if ~exist(tex_file_name_path ,'dir'); mkdir(tex_file_name_path ); end
%% Naming of all inside folders
programms_folder = pwd;
%% Go to folder
cd(excel_data_folder);
%% Load saved .mat file
load(file_to_load_sample);
%% super_tab_cell � a c�lula com todos os dados da tabela
% o c�digo foi feito para strings e neste caso est� tudo misturado
% super_tab_cell_to_tex =
h = fc_lib_latex_cell_to_tab_line(exp_cell{1}{2}(2:end),'\hline'); % BATATA
tb = fc_lib_latex_cell_to_tab_line(new_super_tab);
h_tb = char(h,tb);
h_tb = fc_lib_latex_ponto_para_virgula(h_tb);
m = size(exp_cell{1}{2}(2:end),2); % BATATA
alinhamento = 'c';
c = repmat(alinhamento,1,m);
% BATATA: O que fazer quando corrigir o problema do nome de composto muito
%   grande
if m == 6
    c = sprintf('p{4.8cm}%s', c(2:end));
end
caption_label = {caption_name, label_name};
table_style_1 = fc_lib_latex_add_tabular_longtable(c,h_tb,2);
table_style_2 = fc_lib_latex_add_tabular_longtable(c,h_tb,1,caption_label);
%% save tex table
str_ext = '.tex';
fc_lib_save_file_extensao(tex_file_name_1, str_ext, table_style_1);
fc_lib_save_file_extensao(tex_file_name_2, str_ext, table_style_2);
%% Replacing non-desired values
cd(tex_file_name_path);
% input = {'%', '$$','_','#','\%\%','input\_longtab\_results\_retention\_time\_02'};
% output = {'\%', '', '\_', '','%%', 'input_longtab_results_retention_time_02'};
tex_file_in_label = sprintf('%s_%s',tex_radical,tex_file_name{3});
input = {'%', '$$','_','#','\%\%',strrep(tex_file_in_label,'_','\_')};
output = {'\%', '', '\_', '','%%', tex_file_in_label};
encod = 'ISO-8859-1';
flag_copy = 0;
fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);
%% Return to Programms folder
cd(programms_folder);
end
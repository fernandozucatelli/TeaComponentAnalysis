%% fc_graph_maximum_points_epsilon
%%%%%%%%%%%%%
% help fc_graph_maximum_points_epsilon
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to plot the spectogram without filtering and with each given
% filter value. It also saves each figure with the respective filter value
% in the name and in the title
%%%%%%%%%%%%% Sort library
% fc_lib_sort_search_filtering_pts_dist_eps
%%%%%%%%%%%%%
% version 01: 09.12.2019 -- Creation
% version 02: 10.12.2019 -- Update to deal with new type of entry and flag
%   to select if the plot of figure is desired.
%%%%%%%%%%%%%
%% algorithm
function coordenadas_cell = fc_graph_maximum_points_epsilon(dados, value_filter, pts_searched, epsilon, ...
    passo, dy, fig_save_path, flag_fig)
%% Carregar dados
M = dados{1};
file_name = dados{6};
cor = dados{7};
farbe = fc_get_color_to_graph(cor);
prp = [210 14 197]/255; % Dark Purple
%% Cell to store all coordinates to max and min analysis
coordenadas_cell = cell(1,length(value_filter));
%% Loop for filtered data
for f = 1:length(value_filter)
    %% Filtering
    filtro = value_filter(f);
    M_0 = fc_filtering_for_zero(M,filtro);
    M_f = dados{f+1};
    %% Sorting for maximum
    [S, I] = sort(M_f(:,3));
    %% Filtering maximum peaks closer than epsilon
    tam = length(I);
    pts = fc_lib_sort_search_filtering_pts_dist_eps(M_f(:,1), I, pts_searched, tam, epsilon);
    while pts(end,1) == 0
        pts = pts(1:end-1,:);
    end
    coord = [pts(:,1),S(end-pts(:,2))];
    if flag_fig == 1
        %% Sorting for temporal order
        [R, J] = sort(pts(:,1));
        %% plot data
        f1 = figure(1);
        % set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        %% Plot maximum points
        plot(coord(:,1),coord(:,2), 'o','MarkerSize',12);
        xlabel('Tempo Reten��o [min]'); % Input
        ylabel('Intensidade Relativa'); % Input
        titulo = sprintf('%s: filtro = %2d%%',file_name,filtro); % Input
        t = title(titulo,'Interpreter','none','HorizontalAlignment','Left');
        t.Position = [0 t.Position(2:end)];
        %% Copying figure
        a1 = gca;
        f3 = figure(3);
        copyobj(a1,f3);
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        %% Intensity order
        figure(f1); hold all;
        for k = 1:size(pts,1)
            % str = sprintf('P%02d: (%g, %g)', k,pts(k,1),S(end-pts(k,2)));
            % str = sprintf('%d: %.1f', k,pts(k,1));
            str = sprintf('%d', k);
            text(pts(k,1),S(end-pts(k,2)) + dy, str, 'FontWeight', 'Bold');
        end
        a1 = gca;
        f2 = figure(2);
        copyobj(a1,f2);
        
        figure(f1); hold all;
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        plot(M(:,1),M(:,3), 'Color',farbe,'LineStyle','--');
        plot(M_f(:,1),M_f(:,3), 'Color',farbe,'LineStyle',':','LineWidth',1.5);
        v = axis; set(gca,'xtick',v(1):passo:v(2)); grid on; hold off;
        set(gca,'TickLength',[0,0]);
        
        figure(f2); hold all;
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        plot(M_0(:,1),M_0(:,3), 'Color',farbe,'LineStyle','-');
        v = axis; set(gca,'xtick',v(1):passo:v(2)); grid on; hold off;
        set(gca,'TickLength',[0,0]);
        
        %% Time order
        figure(f3); hold all;
        for k = 1:size(pts,1)
            % str = sprintf('P%02d: (%g, %g)', k,pts(k,1),S(end-pts(k,2)));
            % str = sprintf('%d: %.1f', k,R(k));
            str = sprintf('%d', k);
            text(R(k),S(end-pts(J(k),2)) + dy, str,'Color', prp,...
                'FontWeight', 'Bold');
        end
        a3 = gca;
        f4 = figure(4);
        copyobj(a3,f4);
        
        figure(f3); hold all;
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        plot(M(:,1),M(:,3), 'Color',farbe,'LineStyle','--');
        plot(M_f(:,1),M_f(:,3), 'Color',farbe,'LineStyle',':','LineWidth',1.5);
        v = axis; set(gca,'xtick',v(1):passo:v(2)); grid on; hold off;
        set(gca,'TickLength',[0,0]);
        
        figure(f4); hold all;
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        plot(M_0(:,1),M_0(:,3), 'Color',farbe,'LineStyle','-');
        v = axis; set(gca,'xtick',v(1):passo:v(2)); grid on; hold off;
        set(gca,'TickLength',[0,0]);
        
        %% Save figures
        fig_save_name = sprintf('%s/fig_pts_max_f1_%s_filter_%02d', ...
            fig_save_path, file_name, filtro);
        saveas(f1,fig_save_name,'png');
        fig_save_name = strrep(fig_save_name,'pts_max_f1','pts_max_f2');
        saveas(f2,fig_save_name,'png');
        fig_save_name = strrep(fig_save_name,'pts_max_f2','pts_max_f3');
        saveas(f3,fig_save_name,'png');
        fig_save_name = strrep(fig_save_name,'pts_max_f3','pts_max_f4');
        saveas(f4,fig_save_name,'png');
        % plot(coordenadas(:,1),coordenadas(:,2),'x','MarkerSize',12);
        close all;
    end
    %% Coordinates to create table
    coordenadas_cell{f} = coord;
end
save_name = sprintf('%s/pts_max_%s.mat', fig_save_path, file_name);
save(save_name,'coordenadas_cell');
end

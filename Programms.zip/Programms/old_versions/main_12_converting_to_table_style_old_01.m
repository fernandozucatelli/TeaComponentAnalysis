%% script_converting_to_table_style
load('teste_tabela_amostras.mat');
%%
n_amostras = size(exp_cell,1);
linhas = size(new_super_tab,1);
pos_amostra = 5;
base_columns = 2; % It should be 3 with the colum with the names
%% 
base_tab_cell = cell(linhas,2*n_amostras);
%% main
count = 1; repeticoes = 0;
for k = 1:linhas
    base_tab_cell(k,:) = {'NaN'};
    pos = 1;
    amostra = exp_cell{pos}{1}(1:end-5);
    while pos <= n_amostras && ~strcmp(new_super_tab{k,pos_amostra}, amostra)
        pos = pos + 1;
        amostra = exp_cell{pos}{1}(1:end-5);
    end
    base_tab_cell(count,2*pos-1:2*pos) = new_super_tab(k,3:4);
    % new_super_tab{k,3:4};
    count = count + 1;
    if k >= 2 && strcmp(new_super_tab{k,2},new_super_tab{k-1,2})
        count = count - 1;
        repeticoes = repeticoes + 1;
    end
end
%%
fprintf('repeti��es = %d\n',repeticoes);
base_tab_cell = base_tab_cell(1:count-1,:); %base_tab_cell(1:end-repeticoes,:);
%% 
base_header = exp_cell{1}{2}(4:5);
repeted_header = cell(1,2*n_amostras);
sample_header = cell(1,n_amostras);
for k = 1:n_amostras
    amostra = exp_cell{k}{1}(1:end-5);
    sample_header{k} = sprintf('\\multicolumn{2}{c}{%s}',amostra);
    repeted_header(2*k-1:2*k) = base_header;
end
h1 = fc_lib_latex_cell_to_tab_line(sample_header);
h2 = fc_lib_latex_cell_to_tab_line(repeted_header,'\hline');
h = char(h1,h2);
%% table
tb = fc_lib_latex_cell_to_tab_line(base_tab_cell);
h_tb = char(h,tb);
h_tb = fc_lib_latex_ponto_para_virgula(h_tb);
%% LaTeX
m = 2*n_amostras;
c = repmat('c',1,m);
tabela_style_1 = fc_lib_latex_add_tabular_longtable(c,h_tb,2);
str_ext = '.tex';
tex_file_name = '../Relatorio/input_longtab_results_retention_time_03';
fc_lib_save_file_extensao(tex_file_name, str_ext, tabela_style_1);
%% Replacing non-desired values
PATH = '../Relatorio/';
cd(PATH);
filter = {'retention_time_03'};
% input has negative signal therefore the substituition does not mistake it with
%   any number of min/max part of the table
input = {'%', 'NaN','_','\%\%', '#', '$$'};
output = {'\%', '--', ' ', '%%', '', ''};
encod = 'ISO-8859-1';
flag_copy = 0;
fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);
cd('../data_for_analysis_excel_gcms_table');
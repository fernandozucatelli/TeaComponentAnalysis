%% main_05_table_creation
%%%%%%%%%%%%%
% help main_05_table_creation
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to write a LaTeX table from the data of all matrices
%   and sketch load data to pca
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%%
% fc_lib_save_file_extensao
%%%%%%%%%%%%%
% Source: fhz (2019). Matlab to LaTeX Library
% (https://www.mathworks.com/matlabcentral/fileexchange/72155-matlab-to-latex-library),
% MATLAB Central File Exchange. Retrieved December 3, 2019.
%%%%%%%%%%%%%
% fc_lib_latex_cell_to_tab_line
% fc_lib_latex_tab_num
% fc_lib_latex_ponto_para_virgula
% fc_lib_latex_string_add_lines
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 07.12.2019 -- Renamed from: script_criar_tabela
%   to: main_05_table_creation
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
% version 03: 10.12.2019 -- Renamed from: "main_04" to "main_05" because it
%   is dependent of the results from the old "main_05".
%   Update to get points from figures_with_maximum
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc;
%% Naming of all inside folders
all_data_folder = 'data_for_analysis';
filtered_M_file = 'data_all_M_filtered';
new_fig_max_folder = 'figures_with_maximum';
% new_fig_folder = 'figures_with_maximum';
%% Name of the file
filtered_M_folder = 'filtered_mat';
%% Fixed filters
folder_filter = {'lote'};
total_filters = 4;
total_colors = 5;
total_columns = 2*total_colors + 3;
%% Load folder
txt_folder = sprintf('../%s',all_data_folder);
cd(txt_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
L = length(folders_list);
%% Super data matrix
data_mat = zeros(4*L,total_columns);
%% Loop for all folders
for j = 1:L
    %% Go to the folder
    folder = char(folders_list(j));
    cd(folder);
    %% Loading matrix
    % load_name = sprintf('%s/%s.mat', filtered_M_folder, filtered_M_file);
    load_name = sprintf('%s/all_pts_max_%s.mat', new_fig_max_folder, folder);
    load(load_name);
    %% Minimum and maximum for all times
    minimos = (NaN)*ones(total_colors,total_filters);
    maximos = (-1)*ones(total_colors,total_filters);
    for k = 1:size(all_M_filtered,1)
        cor = all_M_filtered{k,5};
        switch cor
            case 'AM'; pos = 1;
            case 'BR'; pos = 2;
            case 'PR'; pos = 3;
            case 'VD'; pos = 4;
            case 'VM'; pos = 5;
            otherwise; error('"cor" is not defined');
        end
        for f = 1:total_filters
            mm = min(all_M_filtered{k,f}(:,1));
            
            if isnan(minimos(pos,f))
                minimos(pos,f) = mm;
            end
            
            maximo = max(all_M_filtered{1}(:,1));
            if mm < minimos(pos,f)
                minimos(pos,f) = mm;
            elseif maximo > maximos(pos,f)
                maximos(pos,f) = maximo;
            end
        end
    end
    %% Extracting general min and max
    min_tempo_geral = min(minimos);
    max_tempo_geral = max(maximos);
    %% Preparing data
    data = zeros(total_filters, total_columns);
    data(:,1:3) = [(j-1)*ones(total_filters,1), min_tempo_geral', max_tempo_geral'];
    for k = 1:total_colors
        data(:,2*k+2:2*k+3) = [minimos(k,:)', maximos(k,:)'];
    end
    %% data matrix
    data_mat((j-1)*total_filters + 1:j*total_filters,:) = data;
    %% One folder up
    cd('../');
end
%% Preparing header -- first and second line
% header = {'Composto','Tempo de reten��o', 'Tempo de reten��o','Amarelo', 'Amarelo',...
%     'Branco','Branco','Verde','Verde','Preto','Preto','Vermelho','Vermelho'};
header = {'Lote',...
    '\multicolumn{2}{c}{Tempo de reten��o}', '\multicolumn{2}{c}{Amarelo}', ...
    '\multicolumn{2}{c}{Branco}', '\multicolumn{2}{c}{Verde}', ...
    '\multicolumn{2}{c}{Preto}', '\multicolumn{2}{c}{Vermelho}'};
N = 2*length(header) - 1;
txt_min_max = {'min','max'};
h2 = cell(N,1); h2(1) = {''};
for k = 2:2:N
    h2(k:k+1) = {char(txt_min_max(1)), char(txt_min_max(2))};
end
%% Creating the content to LaTeX
l1 = fc_lib_latex_cell_to_tab_line(header);
l2 = fc_lib_latex_cell_to_tab_line(h2','\hline');
flag_math = 1; % flag_longtable = 2 => commented
tb = fc_lib_latex_tab_num(data_mat,'%.1f',2,'c',0,flag_math,2);
str = fc_lib_latex_ponto_para_virgula(tb);
%% Inserting \hline each 4 steps
s = '\hline';
for num = (4*(L-1)+2):-4:2+4
    str = fc_lib_latex_string_add_lines(str,num,s);
end
%% Inserting l1 and l2 into the automatically generated numerical table
num = [2, 2];
s = char(l1, l2);
str = fc_lib_latex_string_add_lines(str,num,s);
%% LaTeX Table Automatic Generated
str_ext = '.tex';
file_name = '../Relatorio/input_longtab_results';
fc_lib_save_file_extensao(file_name, str_ext, str);
%% Replacing non-desired values
PATH = '../Relatorio/';
cd(PATH);
filter = {'longtab'};
input = {'$NaN$','$-1{,}0$'};
output = {'-','-'};
encod = 'ISO-8859-1';
flag_copy = 0;
fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);
cd('../Programms');
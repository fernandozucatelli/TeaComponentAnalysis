%% main_06_table_to_pca
%%%%%%%%%%%%%
% help main_06_table_to_pca
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to prepare the data to the pca analysis
%%%%%%%%%%%%%
% version 01: 09.12.2019 -- Creation
% version 02: 2020-02-13 -- Revision with Roberta
%%%%%%%%%%%%%
%% algorithm
%% Rascunho -- Constru��o dados tal como positivo
% Essa n�o � a melhor abordagem
% Os gr�ficos estavam melhores sem essa opera��o
dados_rows = 0;
for k = 1:length(all_M_filtered)
    x = size(all_M_filtered{k},1);
    if x > dados_rows
        dados_rows = x;
    end
end
qtde_experimento = size(all_M_filtered,1);
escala = 10;
dados = zeros(escala*dados_rows,qtde_experimento);
for k = 1:length(all_M_filtered)
    x = all_M_filtered{k};
    y = escala*x(:,1);
    z = round(y,0);
    dados(z,k) = x(:,3);
end
%%
x_lim = 7*10^2;
plot(dados(1:x_lim,1:3)); % plot(dados);
xlabel('Cent�simo de minuto'); % Input
ylabel('Intensidade Relativa'); % Input
%%
P = pca(dados);
plot(P(:,1:3));
%%
cd('../');
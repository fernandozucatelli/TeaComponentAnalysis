%% main_03_graphs_and_colors
%%%%%%%%%%%%%
% help main_03_graphs_and_colors
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to plot the graphs of all colors from a given sample in separated
%   subplots
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 07.12.2019 -- Renamed from: script_graphs_and_colors
%   to: main_03_graphs_and_colors
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
%%%%%%%%%%%%%
%% main_03_graphs_and_colors
clear; close all; clc;
%% Parameters
value_filter = 10;
%% Naming of all inside folders
all_data_folder = 'data_for_analysis';
new_mat_folder = 'only_data_mat';
programms_folder = 'Programms/';
%% Naming figure and its folder
pasta_figura = 'Figures_to_Comparing_Samples';
fig_base_name = 'subplots_same_type';
%% Fixed filters
mat_filter = {'.mat'};
folder_filter = {'lote'};
%% Load all txt file of a folder
txt_folder = sprintf('../%s',all_data_folder);
cd(txt_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
% folders_list = folders_list(2:end);
% cd('../'); % cd(programms_folder);
%% Loop for all folders
for j = 2 %2:length(folders_list) %1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    cd(folder);
    %% Load list of files -- go to folder and come back
    cd(new_mat_folder);
    % extension = {'.mat'}; % Load all
    % filtro = {'PU'}; % Load some
    filtro = {'C'}; % Load some
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,filtro);
    cd('../');
    %% Parameters
    fh = figure(1);
    % set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
    set(gcf, 'Units','normalized','OuterPosition',[1.02 0.05 0.9 0.88]);
    hold all;
    % grid on; hold on;
    % xlabel('Tempo Reten��o'); ylabel('Intensidade Relativa');
    qtde_colors = 4;
    passo = 2;
    % tipo = char(filtro(1));
    tipo = folder(end-5:end);
    titulo = sprintf('Amostra "%s"', tipo);
    %% Loop
    L = length(filelist); aux = 0; aux_limite = 3;
    for k = 1:L
        total_linhas_subplot = min(L,aux_limite);
        aux = aux + 1;
        if aux > 2*aux_limite; aux = 1; end
        % === Carregar para os an�lise
        file_name = sprintf('%s/%s', new_mat_folder, char(filelist(k)));
        load(file_name);
        % x1 = strfind(file_name,'/');
        % x2 = strfind(file_name,'.');
        % x = file_name(x1+1:x2-1);
        id = strrep(file_name,'_',' ');
        % if size(filelist,1) <= 4
        if ~contains(folder,'00')
            if k == 1
                legendtext = id;
            else
                legendtext = char(legendtext, id);
            end
            pos = 100*total_linhas_subplot + 20 + aux;
            subplot(pos);
            plot(M(:,1),M(:,3));
            grid on;
            v = axis;
            set(gca,'xtick',v(1):passo:v(2));
            legend(id, 'Location','Best');
        else
            fc_graph_por_cor(fh, M, cor, qtde_colors, passo);
        end
    end
    %% Legends
    % if size(filelist,1) <= 4
    if ~contains(folder,'00')
        grid on;
        v = axis;
        set(gca,'xtick',v(1):passo:v(2));
        legend(legendtext, 'Location','Best');
    else
        pos = 100*qtde_colors + 12;
        if qtde_colors == 5
            h1 = subplot(pos); legend('AM','Location','NorthWest');
        else
            pos = pos - 1;
            h1 = subplot(pos); legend('BR','Location','NorthWest');
        end
        pos = pos + 1;
        subplot(pos); legend('VD','Location','NorthWest');
        pos = pos + 1;
        subplot(pos); legend('PR','Location','NorthWest');
        pos = pos + 1;
        h2 = subplot(pos); legend('VM','Location','NorthWest');
        p1 = get(h1,'Position');
        p2 = get(h2,'Position');
        height = p1(2)+p1(4)-p2(2);
        h3 = axes('Position',[p2(1) p2(2) p2(3) height],'Visible','off');
    end
    ylabel('Intensidade Relativa','Visible','on');
    xlabel('Tempo Reten��o [min]','Visible','on');
    title(titulo,'Visible','on');
    hold off;
    %% Creating a folder and saving in it
    if ~exist(pasta_figura, 'dir'); mkdir(pasta_figura); end
    fig_name = sprintf('%s/%s_tipo_%s', pasta_figura,fig_base_name,tipo);
    saveas(gcf,fig_name,'png');
    %%
    cd('../');
end
cd('../../'); cd(programms_folder);
%% function to subplot acoordingly to the color
function fc_graph_por_cor(fh, M, cor, num, passo)
figure(fh);
farbe = fc_get_color_to_graph(cor);
switch cor
    case 'AM'; pos = 511;
    case 'BR'; pos = 100*num + 12;
    case 'VD'; pos = 100*num + 13;
    case 'PR'; pos = 100*num + 14;
    case 'VM'; pos = 100*num + 15;
    otherwise; error('"cor" is not defined');
end
if num == 4; pos = pos - 1; end
subplot(pos); hold all; grid on;
plot(M(:,1),M(:,3), 'Color',farbe);
v = axis;
set(gca,'xtick',v(1):passo:v(2));
end

%% main_05_get_filter_plot_maxima
%%%%%%%%%%%%%
% help main_05_get_filter_plot_maxima
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to create each individual plot identifying a set of maximum
%   peaks away epsilon from each other
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%% From sort library
% fc_lib_sort_search_filtering_pts_dist_eps
%%%%%%%%%%%%%
% version 01: 08.12.2019 -- Creation
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc;
%% Parameters
value_filter = [1 5 10 20];
pts_searched = 10;
epsilon = 0.5;
passo = 2;
dy = 5;
%% Folders
programms_folder = 'Programms/';
new_mat_folder = 'only_data_mat';
all_data_folder_lote00 = '../data_for_analysis/pasta_lote00';
new_fig_folder = 'figures_with_maximum';
%% Creating folders to store new files
fig_save_path = sprintf('%s/%s',all_data_folder_lote00,new_fig_folder);
if ~exist(fig_save_path,'dir'); mkdir(fig_save_path); end    
%% Go to folder
go_to_folder = sprintf('%s/%s',all_data_folder_lote00, new_mat_folder);
cd(go_to_folder);
%% Creating list of files
PATH = pwd; % this folder
mat_filter = {'.mat'};
% flag_copy_to_edit_changes = 0; flag_store_with_PATH = 0;
filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(PATH,0,0,mat_filter);
%% Come back to folder with programms
cd('../../../'); cd(programms_folder);
%% Loop for all folders
for k = 1:length(filelist)
    file_name_ext = char(filelist(k));
    %% Load files
    load_name = sprintf('%s/%s',go_to_folder,file_name_ext);
    load(load_name);
    %% Call graph function
    fc_graph_maximum_points_epsilon(M, value_filter, pts_searched, epsilon, ...
        passo, dy, cor, fig_save_path, file_name);
    close all;
end
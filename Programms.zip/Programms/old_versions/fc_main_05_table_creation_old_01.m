%% fc_main_05_table_creation
%%%%%%%%%%%%%
% help fc_main_05_table_creation
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to write a LaTeX table from the data of all matrices
%   and sketch load data to pca
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%%
% fc_lib_save_file_extensao
%%%%%%%%%%%%%
% Source: fhz (2019). Matlab to LaTeX Library
% (https://www.mathworks.com/matlabcentral/fileexchange/72155-matlab-to-latex-library),
% MATLAB Central File Exchange. Retrieved December 3, 2019.
%%%%%%%%%%%%%
% fc_lib_latex_cell_to_tab_line
% fc_lib_latex_tab_num
% fc_lib_latex_ponto_para_virgula
% fc_lib_latex_string_add_lines
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 07.12.2019 -- Renamed from: script_criar_tabela
%   to: fc_main_05_table_creation
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
% version 03: 10.12.2019 -- Renamed from: "main_04" to "main_05" because it
%   is dependent of the results from the old "main_05".
%   Update to get points from figures_with_maximum
% version 04: 10.12.2019 -- Updated usage of "all_M_filtered" to
%   "all_coordenadas_cell"
% version 05: 2020-02-13 -- Revision with Roberta
%%%%%%%%%%%%%
%% algorithm
function fc_main_05_table_creation(path_all_data_folder, all_data_folder,...
    folder_filter, parameters_test, report_PATH, file_sufix_name, ...
    flag_TeX0_Word1, new_label_MSWord)
%% Naming of all inside folders
% all_data_folder = 'data_for_analysis'; % Input
% filtered_M_file = 'data_all_M_filtered';
% filtered_M_folder = 'filtered_mat';
new_fig_max_folder = 'figures_with_maximum';
programms_folder = pwd;
if ~exist(report_PATH,'dir'); mkdir(report_PATH); end
%% Fixed filters
total_filters = parameters_test(1);
total_colors = parameters_test(2);
total_columns = 2*total_colors + 3;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
L = length(folders_list);
%% Super data matrix
data_mat = zeros(4*L,total_columns);
%% Loop for all folders
for j = 1:L
    %% Go to the folder
    folder = char(folders_list(j));
    cd(folder);
    %% Loading matrix
    % load_name = sprintf('%s/%s.mat', filtered_M_folder, filtered_M_file);
    load_name = sprintf('%s/all_pts_max_%s.mat', new_fig_max_folder, folder);
    load(load_name); % all_coordenadas_cell is loaded
    %% Minimum and maximum for all times
    minimos = (NaN)*ones(total_colors,total_filters);
    maximos = (NaN)*ones(total_colors,total_filters);
    for k = 1:size(all_coordenadas_cell,1)
        cor = all_coordenadas_cell{k,end};
        switch cor
            case 'AM'; pos = 1;
            case 'BR'; pos = 2;
            case 'PR'; pos = 3;
            case 'VD'; pos = 4;
            case 'VM'; pos = 5;
            otherwise; error('"cor" is not defined');
        end
        for f = 1:total_filters
            mi = min(all_coordenadas_cell{k,f}(:,1));
            ma = max(all_coordenadas_cell{k,f}(:,1));

            if isnan(minimos(pos,f))
                minimos(pos,f) = mi;
            elseif mi < minimos(pos,f)
                minimos(pos,f) = mi;
            end

            if isnan(maximos(pos,f))
                maximos(pos,f) = ma;
            elseif ma > maximos(pos,f)
                maximos(pos,f) = ma;
            end
        end
    end
    %% Extracting general min and max
    min_tempo_geral = min(minimos);
    max_tempo_geral = max(maximos);
    %% Preparing data
    % first column for lote is negative to enable simple text substitution
    data = zeros(total_filters, total_columns);
    data(:,1:3) = [-(j-1)*ones(total_filters,1), min_tempo_geral', max_tempo_geral'];
    for k = 1:total_colors
        data(:,2*k+2:2*k+3) = [minimos(k,:)', maximos(k,:)'];
    end
    %% data matrix
    data_mat((j-1)*total_filters + 1:j*total_filters,:) = data;
    %% One folder up
    cd('../');
end
%% LaTeX vs MSWord division is mandatory
% LaTeX is better, everyone should use it.
% MSWord is a constraint for many people.
% Therefore, give people choice, but give people knowledge to choose.
if flag_TeX0_Word1 == 0
    %% Preparing header -- first and second line
    % header = {'Composto','Tempo de reten��o', 'Tempo de reten��o','Amarelo', 'Amarelo',...
    %     'Branco','Branco','Verde','Verde','Preto','Preto','Vermelho','Vermelho'};
    header = {'Lote',...
        '\multicolumn{2}{c}{Tempo de reten��o}', '\multicolumn{2}{c}{Amarelo}', ...
        '\multicolumn{2}{c}{Branco}', '\multicolumn{2}{c}{Verde}', ...
        '\multicolumn{2}{c}{Preto}', '\multicolumn{2}{c}{Vermelho}'};
    N = 2*length(header) - 1;
    txt_min_max = {'min','max'};
    h2 = cell(N,1); h2(1) = {''};
    for k = 2:2:N
        h2(k:k+1) = {char(txt_min_max(1)), char(txt_min_max(2))};
    end
    %% Creating the content to LaTeX
    l1 = fc_lib_latex_cell_to_tab_line(header);
    l2 = fc_lib_latex_cell_to_tab_line(h2','\hline');
    flag_math = 1; % flag_longtable = 2 => commented
    tb = fc_lib_latex_tab_num(data_mat,'%.1f',2,'c',0,flag_math,2);
    str = fc_lib_latex_ponto_para_virgula(tb);
    %% Inserting \hline each 4 steps
    s = '\hline';
    for num = (4*(L-1)+2):-4:2+4
        str = fc_lib_latex_string_add_lines(str,num,s);
    end
    %% Inserting l1 and l2 into the automatically generated numerical table
    num = [2, 2];
    s = char(l1, l2);
    str = fc_lib_latex_string_add_lines(str,num,s);
    %% LaTeX Table Automatic Generated
    str_ext = '.tex';
    tex_file_name = sprintf('%s/%s_%s',report_PATH,'input_longtab',file_sufix_name);
    fc_lib_save_file_extensao(tex_file_name, str_ext, str);
    %% Replacing non-desired values

    cd(report_PATH);
    filter = {'input_longtab'};
    % input has negative signal therefore the substituition does not mistake it with
    %   any number of min/max part of the table
    input = cell(1,L);
    output = cell(1,L);
    input(1) = {'$NaN$'};
    output(1) = {'--'};
    for j = 1:L
        input(j+1) = {sprintf('$-%d{,}0$',j-1)};
        output(j+1) = {sprintf('$%d$',j-1)};
    end
    encod = 'ISO-8859-1';
    flag_copy = 0;
    fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);
else
    word_file_name = sprintf('%s_%s.doc','input_tab_word',file_sufix_name);

    if contains(report_PATH,'..') == 1
        cd('..');
        report_PATH = sprintf('%s/%s',pwd,report_PATH(3:end));
    end

    FileSpec = fullfile(report_PATH,word_file_name);
    [ActXWord,WordHandle] = fc_lib_msword_start_Word(FileSpec,0);

    % tab_cell = num2cell(data_mat,size(data_mat));
%     tab_cell = {
%         ' ', ' ', 'Merge_1', '', 'Merge_2', '';
%         '0', '1', '2', '3', '4,00', '5';
%         '10', '11', '12', '13', '14,00', '15';
%         'Super_Merge_1', '', '', 'Merge_3', '', '';
%         '', 'X', '2', '3', '4,00', '5';
%         '10', '11', '12', '13', '14,00', 'Row_Merge_1';
%         '0', '1', '2', '3', '4,00', '';
%         'Merge_4', '', 'Merge_5', '', '', '15'};
    tab_cell = sprintfc('%g',data_mat);

    [NoRows,NoCols] = size(tab_cell);
    tab_align = 'wdAlignRowCenter';
    text_align = 3;

    separator = ' --';

    ActXWord.CaptionLabels.Add(new_label_MSWord);
    ActXWord.Selection.InsertCaption(new_label_MSWord, separator, ...
        '', 0, false);
    ActXWord.Selection.TypeText(' Automatically created Table.');
    ActXWord.Selection.TypeParagraph;

    % colMerge = {1, [2,3; 4,5; 6,7; 8,9]};
    colMerge = '';
    row_lines = 4:4:NoRows;

    fc_lib_msword_create_table(ActXWord,NoRows,NoCols,tab_cell,0,...
        tab_align,text_align,colMerge,'','',row_lines);

    ActXWord.Selection.TypeParagraph;
    fc_lib_msword_close_Word(ActXWord,WordHandle,FileSpec);
end
cd(programms_folder);
end
%% main_02_matrix_filtering
%%%%%%%%%%%%%
% help main_02_matrix_filtering
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to create a single cell with all matrices after filtering small
%   values
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 01.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 04.12.2019 -- Renamed from: script_mat_analysis
%   to: main_02_matrix_filtering
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
%%%%%%%%%%%%%
%% main_02_matrix_filtering
clear; close all; clc; tic;
%% Parameters
value_filter = [1 5 10 20];
num_colums_M_filtered = length(value_filter) + 4; % M cor sabor marca estado
%% Naming of all inside folders
all_data_folder = 'data_for_analysis';
new_mat_folder = 'only_data_mat';
filtered_M_folder = 'filtered_mat';
programms_folder = 'Programms/';
%% Fixed filters
mat_filter = {'.mat'};
folder_filter = {'lote'};
%% Name of the file
filtered_M_file = 'data_all_M_filtered';
%% Load all txt file of a folder
txt_folder = sprintf('../%s',all_data_folder);
cd(txt_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
% folders_list = folders_list(2:end);
cd('../'); cd(programms_folder);
%% Loop for all folders
for j = 1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    go_to_folder = sprintf('../%s/%s',all_data_folder, folder);
    cd(go_to_folder);
    %% creating folders to store new files
    if ~exist(filtered_M_folder, 'dir'); mkdir(filtered_M_folder); end
    %% Jump to mat folder
    cd(new_mat_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,mat_filter);
    cd('../');
    all_M_filtered = cell(length(filelist),num_colums_M_filtered);
    %% main loop
    for k = 1:length(filelist)
        %% Carregar para os an�lise
        file_name = sprintf('%s/%s', new_mat_folder, char(filelist(k)));
        load(file_name);
        % M_corte = fc_filter_M(M, value_filter);
        for l = 1:length(value_filter)
            M_filtered = M(M(:,3) >= value_filter(l),:);
            all_M_filtered{k,l} = M_filtered;
        end
        all_M_filtered{k,l+1} = cor;
        all_M_filtered{k,l+2} = sabor;
        all_M_filtered{k,l+3} = marca;
        all_M_filtered{k,l+4} = estado;
    end
    save_name = sprintf('%s/%s.mat', filtered_M_folder, filtered_M_file);
    save(save_name,'all_M_filtered');
    %% Come back to main folder
    cd('../../'); cd(programms_folder);
end
toc
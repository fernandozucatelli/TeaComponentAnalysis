%% main_04_table_creation
%%%%%%%%%%%%%
% help main_04_table_creation
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to write a LaTeX table from the data of all matrices
%   and sketch load data to pca
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%%
% fc_lib_save_file_extensao
%%%%%%%%%%%%%
% Source: fhz (2019). Matlab to LaTeX Library
% (https://www.mathworks.com/matlabcentral/fileexchange/72155-matlab-to-latex-library),
% MATLAB Central File Exchange. Retrieved December 3, 2019.
%%%%%%%%%%%%%
% fc_lib_latex_cell_to_tab_line
% fc_lib_latex_tab_num
% fc_lib_latex_ponto_para_virgula
% fc_lib_latex_string_add_lines
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 07.12.2019 -- Renamed from: script_criar_tabela
%   to: main_04_table_creation
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
%%%%%%%%%%%%%
%% main_04_table_creation
clear; close all; clc;
%% Naming of all inside folders
all_data_folder = 'data_for_analysis';
filtered_M_file = 'data_all_M_filtered';
%% Name of the file
filtered_M_folder = 'filtered_mat';
%% Fixed filters
folder_filter = {'lote'};
%% Load all txt file of a folder
txt_folder = sprintf('../%s',all_data_folder);
cd(txt_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
% folders_list = folders_list(2:end);
% cd('../'); cd(programms_folder);
%% Loop for all folders
for j = 1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    cd(folder);
    %% Loading matrix
    load_name = sprintf('%s/%s.mat', filtered_M_folder, filtered_M_file);
    load(load_name);
    %% Minimum and maximum for all times
    minimos = (NaN)*ones(5,1);
    maximos = (-1)*ones(5,1);
    for k = 1:length(all_M_filtered)
        cor = all_M_filtered{k,2};
        switch cor
            case 'AM'; pos = 1;
            case 'BR'; pos = 2;
            case 'PR'; pos = 3;
            case 'VD'; pos = 4;
            case 'VM'; pos = 5;
            otherwise; error('"cor" is not defined');
        end
        mm = min(all_M_filtered{k}(:,1));
        
        if isnan(minimos(pos))
            minimos(pos) = mm;
        end
        
        if mm < minimos(pos)
            minimos(pos) = mm;
        elseif max(all_M_filtered{1}(:,1)) > maximos(pos)
            maximos(pos) = max(all_M_filtered{k}(:,1));
        end
    end
    %% Extracting general min and max
    min_tempo_geral = min(minimos);
    max_tempo_geral = max(maximos);
    %% Preparing data
    data = zeros(1, 2*pos + 2);
    data(1:3) = [0, min_tempo_geral, max_tempo_geral];
    for k = 1:pos
        data(2*k+2:2*k+3) = [minimos(k), maximos(k)];
    end
    %% Preparing header -- first and second line
    % header = {'Composto','Tempo de reten��o', 'Tempo de reten��o','Amarelo', 'Amarelo',...
    %     'Branco','Branco','Verde','Verde','Preto','Preto','Vermelho','Vermelho'};
    header = {'Composto',...
        '\multicolumn{2}{c}{Tempo de reten��o}', '\multicolumn{2}{c}{Amarelo}', ...
        '\multicolumn{2}{c}{Branco}', '\multicolumn{2}{c}{Verde}', ...
        '\multicolumn{2}{c}{Preto}', '\multicolumn{2}{c}{Vermelho}'};
    N = 2*length(header) - 1;
    txt_min_max = {'min','max'};
    h2 = cell(N,1); h2(1) = {''};
    for k = 2:2:N
        h2(k:k+1) = {char(txt_min_max(1)), char(txt_min_max(2))};
    end
    %% Creating the content to LaTeX
    l1 = fc_lib_latex_cell_to_tab_line(header);
    l2 = fc_lib_latex_cell_to_tab_line(h2','\hline');
    flag_math = 1;
    tb = fc_lib_latex_tab_num(data,'%g',2,'c',0,flag_math);
    tb = fc_lib_latex_ponto_para_virgula(tb);
    %% Correcting $0$ to the sample name
    % Ainda n�o sei bem como implementar essa corre��o
    % data_with_name = strrep(tb(2,:),'$0$','Tipo de ch�');
    %% Inserting l1 and l2 into the automatically generated numerical table
    num = [2, 2];
    s = char(l1, l2);
    str = fc_lib_latex_string_add_lines(tb,num,s);
    %% LaTeX Table Automatic Generated
    str_ext = '.tex';
    file_name = sprintf('../../Relatorio/input_tab_results_%s', folder);
    fc_lib_save_file_extensao(file_name, str_ext, str);
    %% Rascunho -- Constru��o dados tal como positivo
    % Essa n�o � a melhor abordagem
    % Os gr�ficos estavam melhores sem essa opera��o
    %%{
    dados_rows = 0;
    for k = 1:length(all_M_filtered)
        x = size(all_M_filtered{k},1);
        if x > dados_rows
            dados_rows = x;
        end
    end
    qtde_experimento = size(all_M_filtered,1);
    escala = 10;
    dados = zeros(escala*dados_rows,qtde_experimento);
    for k = 1:length(all_M_filtered)
        x = all_M_filtered{k};
        y = escala*x(:,1);
        z = round(y,0);
        dados(z,k) = x(:,3);
    end
    %}
    %%
    x_lim = 7*10^2;
    plot(dados(1:x_lim,1:3)); % plot(dados);
    xlabel('Cent�simo de minuto');
    ylabel('Intensidade Relativa');
    %%
    P = pca(dados);
    plot(P(:,1:3));
    %%
    cd('../');
end

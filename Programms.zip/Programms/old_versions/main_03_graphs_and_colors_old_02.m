%% main_03_graphs_and_colors
%%%%%%%%%%%%%
% help main_03_graphs_and_colors
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to plot the graphs of all colors from a given sample in separated
%   subplots
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 07.12.2019 -- Renamed from: script_graphs_and_colors
%   to: main_03_graphs_and_colors
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc;
%% Parameters
passos = [2 4]; % 2 4
%% Naming of all inside folders
all_data_folder = 'data_for_analysis';
new_mat_folder = 'only_data_mat';
programms_folder = 'Programms/';
%% Naming figure and its folder
pasta_figura = 'Figures_Comparing_Samples';
fig_base_name = 'fig_subplot_compare';
%% Fixed filters
mat_filter = {'.mat'};
folder_filter = {'lote'};
%% Load all txt file of a folder
txt_folder = sprintf('../%s',all_data_folder);
cd(txt_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
% folders_list = folders_list(2:end);
cd('../'); cd(programms_folder);
%% Loop for all folders
% Not applied to folder lote00
for j = 2:length(folders_list) %1:length(folders_list) % [4 6:9 11 12] % Corrections
    %% Go to the folder
    folder = char(folders_list(j));
    go_to_folder = sprintf('../%s/%s',all_data_folder, folder);
    cd(go_to_folder);
    %% Load list of files -- go to folder and come back
    cd(new_mat_folder);
    filtro = {'.mat'}; % Load all
    % filtro = {'PU'}; % Load some
    % filtro = {'C'}; % Load some
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,filtro);
    cd('../../../'); cd(programms_folder);
    %% Parameters
    tipo = folder(end-5:end);
    titulo = sprintf('Sample "%s"', tipo);
    %% Loop
    L = length(filelist); aux_limite = 6;
    total_linhas_subplot = min(L,aux_limite);
    for p = 1:length(passos)
        aux = 0; cont_fig = 1;
        figure(10*p + cont_fig);
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        %%
        for k = 1:L
            aux = aux + 1;
            if aux > aux_limite
                aux = 1; cont_fig = cont_fig + 1;
                figure(10*p + cont_fig);
                set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
            end
            % === Carregar para os an�lise
            file_name = sprintf('%s/%s/%s/%s', txt_folder, folder, new_mat_folder, char(filelist(k)));
            load(file_name);
            if ~contains(folder,'00')
                legendtext = file_name;
                pos = 100*ceil(total_linhas_subplot/p) + 10*p + aux;
                subplot(pos);
                farbe = fc_get_color_to_graph(cor);
                plot(M(:,1),M(:,3),'Color', farbe);
                v = axis; set(gca,'xtick',v(1):passos(p):v(2)); grid on;
                leg = legend(file_name, 'Location','Best');
                leg.Interpreter = 'none';
            end
        end
    end
    %% Legends
    for p = 1:length(passos)
        for c = 1:cont_fig
            figure(10*p + c);
            pos = 100*ceil(total_linhas_subplot/p) + 10*p + 1;
            h1 = subplot(pos);
            if c > 1 && c == cont_fig
                resto = mod(L,aux_limite);
            else
                resto = total_linhas_subplot;
            end
            pos = 100*ceil(total_linhas_subplot/p) + 10*p + resto;
            h2 = subplot(pos);
            p1 = get(h1,'Position');
            p2 = get(h2,'Position');
            height = p1(2)+p1(4)-p2(2);
            h3 = axes('Position',[p1(1) p2(2) p2(3) height],'Visible','off');
            yl = ylabel('Intensidade Relativa','Visible','on');
            xl = xlabel('Tempo Reten��o [min]','Visible','on');
            if p == 2
                xl.Position = [3.5*p1(3), xl.Position(2:end)];
            end
            t = title(sprintf('%s: fig %02d / %02d ',titulo,c,cont_fig),'Visible','on');
            if  p == 2
                t.Position = [3.5*p1(3), t.Position(2:end)];
            end
            hold off;
        end
    end
    %% Creating a folder and saving in it
    pasta_figura_folder = sprintf('%s/%s/%s', txt_folder, folder, pasta_figura);
    if ~exist(pasta_figura_folder, 'dir'); mkdir(pasta_figura_folder); end
    for p = 1:length(passos)
        for c = 1:cont_fig
            fig_name = sprintf('%s/%s_lote_%s_style_%d_count_%d', pasta_figura_folder, ...
                fig_base_name,tipo,p,c);
            saveas(figure(10*p + c),fig_name,'png');
        end
    end
    close all;
end
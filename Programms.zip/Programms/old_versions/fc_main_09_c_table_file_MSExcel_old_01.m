%% fc_main_09_c_table_file_MSExcel
%%%%%%%%%%%%%
% help fc_main_09_c_table_file_MSExcel
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to create the MSExcel file with the desired table
%%%%%%%%%%%%%
% version 01: 2020-03-01 -- Creation (ISO8601)
%%%%%%%%%%%%%
%% algorithm
function fc_main_09_c_table_file_MSExcel(path_all_data_folder, all_data_folder,...
        folder_filter, filtered_mat_folder, file_to_load_name,...
        XlsReport_folder, XlsName_base)
%% Programm folders
programms_folder = pwd;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Create table folder
if ~exist(XlsReport_folder,'dir'); mkdir(XlsReport_folder); end
%% main
for q = 1:length(folders_list)
    folder = char(folders_list(q));
    go_to_folder = sprintf('%s/%s/%s/%s',path_all_data_folder,all_data_folder, ...
        folder, filtered_mat_folder);
    cd(go_to_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,{file_to_load_name});
    for p = 1:2:length(filelist)
        load_name = char(filelist(p));
        load(load_name);
        load_name = char(filelist(p+1));
        load(load_name);
        %% Naming file
        save_xls_name = sprintf('%s/%s_%s_%02d',XlsReport_folder,XlsName_base,folder,p);
        save_xls_name = fc_lib_backup_filename(save_xls_name);
        %% Writing Spreadsheet
        xlswrite(save_xls_name,base_tab_cell_header,1,'B2');
    end
end
%% Return to Programms folder
cd(programms_folder);
end
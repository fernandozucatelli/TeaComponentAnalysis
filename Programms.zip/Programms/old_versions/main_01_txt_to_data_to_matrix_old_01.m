%% script_carregar_txt_matriz
%%%%%%%%%%%%%
% help script_carregar_txt_matriz
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to get all .txt from the espectroscopy and convert them into a
%   new .txt only with the desired data inside and then transform them
%   again into a matrix.
% The transformation into the same size matrix necessary to final
%   evaluation is made in another separeted script.
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%%
% version 01: 30.11.2019 -- Creation
%%%%%%%%%%%%% Example 01
% Examples must call the function and may call other related functions
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc;
%% Load all txt file of a folder
txt_folder = 'original_data_txt';
cd(txt_folder);
PATH = pwd; % this folder
% flag_copy_to_edit_changes = 0; flag_store_with_PATH = 0;
extension = {'.txt'};
filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(PATH,0,0,extension);
% Remove entry: 'allFilesName.txt'
filelist = filelist(2:end);
cd('../');
%% Fixed Parameters
str_ext = char(extension(1));
% This is the pattern to start the transfer of the data to another file
% pattern = 'Ret.Time';
pattern = 'Absolute';
%% Naming and creating folders to store new files
new_txt_folder = 'only_data_txt';
new_mat_folder = 'only_data_mat';
new_fig_folder = 'only_figures';
if ~exist(new_txt_folder,'dir'); mkdir(new_txt_folder); end
if ~exist(new_mat_folder,'dir'); mkdir(new_mat_folder); end
if ~exist(new_fig_folder,'dir'); mkdir(new_fig_folder); end
%% main loop -- Extracting data
%%{
for k = 1:length(filelist)
    file_name_ext = char(filelist(k));
    fc_single_file_analysis(new_txt_folder, file_name_ext, pattern);
end
%}
%% Another technique
% filename = 'novo_DADOS.txt';
% delimiterIn = ' ';
% headerlinesIn = 0;
% A = importdata(novo_arquivo);
%% main loop -- Transforming new file with data to matrix
%%{
for k = 1:length(filelist)
    file_name_ext = char(filelist(k));
    fc_single_data_file_to_matrix(new_txt_folder, new_mat_folder, file_name_ext);
end
%}
%% main loop -- Load matrix to generate graphs
% Moving to folder with the matrices
cd(new_mat_folder);
extension = {'.mat'};
filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,extension);
for k = 1:length(filelist)
    %% Carregar para os gr�ficos
    file_name = char(filelist(k));
    load(file_name);
    fc_graphs(file_name, M, new_fig_folder);
end
% Moving back to original folder
cd('../');

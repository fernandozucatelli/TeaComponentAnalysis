%% main_04_get_filter_plot_maxima
%%%%%%%%%%%%%
% help main_04_get_filter_plot_maxima
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to create each individual plot identifying a set of maximum
%   peaks away epsilon from each other
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%% From sort library
% fc_lib_sort_search_filtering_pts_dist_eps
%%%%%%%%%%%%%
% version 01: 08.12.2019 -- Creation
% version 02: 10.12.2019 -- Simplifying search after update on main_02
%   Rename from "main_05_..." to "main_04..." because the old main_04 is
%       dependent of the results of this script.
%   Updated to receive data directly from "data_all_M_filtered.mat"
%   Create all_coordenadas_cell with all found points
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc;
%% Parameters
% value_filter = [1 5 10 20]; %loaded from saved data
pts_searched = 10;
epsilon = 0.5;
passo = 2;
dy = 5;
flag_fig = 0;
%% Folders
programms_folder = 'Programms/';
filtered_mat_folder = 'filtered_mat';
all_data_folder = '../data_for_analysis';
new_fig_max_folder = 'figures_with_maximum';
file_all_data = 'data_all_M_filtered.mat';
folder_filter = {'lote'};
%% Go to the folder
cd(all_data_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
% folders_list = folders_list(2:end);
cd('../'); cd(programms_folder);
%% Loop for all folders
fprintf('Iniciado - Start\n');
for j = 1:length(folders_list)
    %% Load data_all_M_filtered
    folder = char(folders_list(j));
    load_name = sprintf('%s/%s/%s/%s',all_data_folder, folder, filtered_mat_folder,file_all_data);
    load(load_name);
    %% Creating folders to store new files
    fig_save_path = sprintf('%s/%s/%s',all_data_folder,folder,new_fig_max_folder);
    if ~exist(fig_save_path,'dir'); mkdir(fig_save_path); end
    %% Evitar repetir figuras j� feitas
    % if j > 1; flag_fig = 0; end
    L = size(all_M_filtered,1);
    all_coordenadas_cell = cell(L,5);
    for k = 1:L
        dados = all_M_filtered(k,:);
        %% Call graph function
        all_coordenadas_cell(k,1:4) = fc_graph_maximum_points_epsilon(dados, value_filter, pts_searched, epsilon, ...
            passo, dy, fig_save_path, flag_fig);
        all_coordenadas_cell{k,5} = all_M_filtered{k,7};
        close all;
    end
    save_name = sprintf('%s/all_pts_max_%s.mat', fig_save_path, folder);
    save(save_name,'all_coordenadas_cell');
end
fprintf('Conclu�do - Finished\n');
%% main_01_txt_to_data_to_matrix
%%%%%%%%%%%%%
% help main_01_txt_to_data_to_matrix
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to get all .txt from the espectroscopy and convert them into a
%   new .txt only with the desired data inside and then transform them
%   again into a matrix.
% The transformation into the same size matrix necessary to final
%   evaluation is made in another separeted script.
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 30.11.2019 -- Creation
% version 02: 02.12.2019 -- Updating to load original data from another
%   folder
%   Auxiliary have also been update
% version 03: 06.12.2019 -- Renamed from: script_carregar_txt_matriz
%   to: main_01_txt_to_data_to_matrix
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
% version 03: 20.12.2019 -- Update only_figure to lote00
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc; tic;
%% Naming of all inside folders
all_data_folder = 'data_for_analysis';
new_txt_folder = 'only_data_txt';
new_mat_folder = 'only_data_mat';
new_fig_folder = 'only_figures';
programms_folder = 'Programms/';
%% Fixed filters
folder_filter = {'lote'};
% folder_filter = {'lote00'};
txt_filter = {'.txt'};
mat_filter = {'.mat'};
str_ext = char(txt_filter(1));
passo = 2;
%% This is the pattern to start the transfer of the data to another file
% pattern = 'Ret.Time';
pattern = 'Absolute';
%% Load all txt file of a folder
txt_folder = sprintf('../%s',all_data_folder);
cd(txt_folder);
PATH = pwd;
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(PATH,0,0,folder_filter);
% folders_list = folders_list(2:end);
cd('../'); cd(programms_folder);
%% Loop for all folders
for j = 1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    go_to_folder = sprintf('../%s/%s',all_data_folder, folder);
    cd(go_to_folder);
    %% Creating folders to store new files
    if ~exist(new_txt_folder,'dir'); mkdir(new_txt_folder); end
    if ~exist(new_mat_folder,'dir'); mkdir(new_mat_folder); end
    if ~exist(new_fig_folder,'dir'); mkdir(new_fig_folder); end
    %% Creating list of files
    PATH = pwd; % this folder
    % flag_copy_to_edit_changes = 0; flag_store_with_PATH = 0;
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(PATH,0,0,txt_filter);
    % Remove entry: 'allFilesName.txt'
    filelist = filelist(2:end);
    %% Come back to folder with programms
    cd('../../'); cd(programms_folder);
    %% all local folders
    txt_folder_lote = sprintf('%s/%s', txt_folder,folder);
    new_txt_folder_lote = sprintf('%s/%s', txt_folder_lote,new_txt_folder);
    new_mat_folder_lote = sprintf('%s/%s', txt_folder_lote,new_mat_folder);
    new_fig_folder_lote = sprintf('%s/%s', txt_folder_lote,new_fig_folder);
    %% main loop -- Extracting data to txt and to matrix
    %%{
    for k = 1:length(filelist)
        file_name_ext = char(filelist(k));
        % new_txt
        fc_single_file_analysis(txt_folder_lote, new_txt_folder_lote, file_name_ext, pattern);
        % txt_to_matrix
        fc_single_data_file_to_matrix(new_txt_folder_lote, new_mat_folder_lote, file_name_ext);
    end
    %}
    %% main loop -- Load matrix to generate graphs
    % Moving to folder with the matrices
    cd(new_mat_folder_lote);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,mat_filter);
    % Moving back to original folder
    cd('../../../'); cd(programms_folder);
    %% Carregar para os gr�ficos
    % Pular o lote 00 -- suas figuras s�o criadas no main_05
    % N�o � mais usado
    for k = 1:length(filelist)
        file_name = char(filelist(k));
        load_name = sprintf('%s/%s',new_mat_folder_lote,file_name);
        load(load_name);
        fc_graphs(file_name, M, passo, new_fig_folder_lote, cor);
    end
end
toc
%% fc_main_09_a_table_file_LaTeX
%%%%%%%%%%%%%
% help fc_main_09_a_table_file_LaTeX
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to create the LaTeX file with the desired table
%%%%%%%%%%%%%
% version 01: 2020-03-01 -- Creation (ISO8601)
%%%%%%%%%%%%%
%% algorithm
function fc_main_09_a_table_file_LaTeX(path_all_data_folder, all_data_folder,...
    folder_filter, filtered_mat_folder, file_to_load_name,...
    tex_file_name_path, table_folder, tex_file, tex_radical, filter)
%% Programm folders
programms_folder = pwd;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Create table folder
cd(tex_file_name_path);
if ~exist(table_folder,'dir'); mkdir(table_folder); end
input_all_tables = '';
%% Return to Programms folder
cd(programms_folder);
%% main
for q = 1:length(folders_list)
    folder = char(folders_list(q));
    go_to_folder = sprintf('%s/%s/%s/%s',path_all_data_folder,all_data_folder, ...
        folder, filtered_mat_folder);
    cd(go_to_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,{file_to_load_name});
    input_tables_folder_filter = '';
    for p = 1:2:length(filelist)
        load_name = char(filelist(p));
        load(load_name);
        load_name = char(filelist(p+1));
        load(load_name);
        tab_name = sprintf('%s_%s_%s_%02d',tex_radical,tex_file{2},folder,p);
        %% Cell to Table -- header
        h1 = fc_lib_latex_cell_to_tab_line(sample_header);
        h2 = fc_lib_latex_cell_to_tab_line(repeated_header,'\hline');
        h = char(h1,h2);
        tb = fc_lib_latex_cell_to_tab_line(base_tab_cell);
        h_tb = char(h,tb);
        h_tb = fc_lib_latex_ponto_para_virgula(h_tb);
        %% save tex table
        format = sprintf('c%s',repmat('|ccc',1,n_amostras));
        caption_label = {caption_name, tab_name};
        tabela_style_1 = fc_lib_latex_add_tabular_longtable(format,h_tb,0,caption_label);
        str_ext = '.tex';
        tex_file_name = sprintf('%s/%s/%s',tex_file_name_path, table_folder, tab_name);
        fc_lib_save_file_extensao(tex_file_name, str_ext, tabela_style_1);
        %% Adding name to local folder tex file
        caption = sprintf('\\caption{%s}',caption_name);
        label = sprintf('\\label{%s}',tab_name);
        input_tables_folder_filter = char(input_tables_folder_filter, ...
            '\clearpage', '\begin{table}[H]', '\centering', caption, ...
            sprintf('\\input{%s/%s}',table_folder,tab_name), label, '\end{table}', '');
    end
    %%
    input_table_folder_name = sprintf('input_longtab_%s',folder);
    tex_file_name = sprintf('%s/%s/%s',tex_file_name_path, table_folder, ...
        input_table_folder_name);
    fc_lib_save_file_extensao(tex_file_name, '.tex', input_tables_folder_filter);
    
    new_input_table = sprintf('\\input{%s/%s}',table_folder,input_table_folder_name);
    input_all_tables = char(input_all_tables,'\clearpage',new_input_table,'');
end
%% Replacing non-desired values
cd(sprintf('%s/%s',tex_file_name_path,table_folder));
% input has negative signal therefore the substituition does not mistake it with
%   any number of min/max part of the table
input = {'%', '_','\%\%', '#', '$$', strrep(tab_name,'_','\_')};
output = {'\%', '\_', '%%', '', '', tab_name};
encod = 'ISO-8859-1';
flag_copy = 0;
fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);
%% Creating input all tables file
input_all_tables_file = 'input_all_tables';
tex_file_name = sprintf('%s/%s',tex_file_name_path, input_all_tables_file);
fc_lib_save_file_extensao(tex_file_name, '.tex', input_all_tables);
%% Return to Programms folder
cd(programms_folder);
end
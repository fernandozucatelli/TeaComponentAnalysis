function fc_graphs(file_name, M, passo, new_fig_folder, labels, cor)
figure(1);
farbe = fc_get_color_to_graph(cor);
plot(M(:,1),M(:,3),'Color', farbe);
xlabel(char(labels{1})); % Input
ylabel(char(labels{2})); % Input
t = title(file_name,'Interpreter','none','HorizontalAlignment','Left');
t.Position = [0 t.Position(2:end)];
set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
v = axis; set(gca,'xtick',v(1):passo:v(2)); grid on;
set(gca,'TickLength',[0,0]);
if ~strcmp(new_fig_folder, '')
    fig_name = sprintf('%s/%s', new_fig_folder,file_name);
    saveas(gcf,fig_name,'png');
end
end
%% Utilizando stem n�o fica bom pelo excesso de zeros
%{
figure(2);
stem(M(:,1),M(:,3)); grid on;
xlabel('Tempo Reten��o'); ylabel('Intensidade Relativa');
if ~strcmp(new_fig_folder, '')
    fig_name = sprintf('%s/%s', new_fig_folder,file_name);
    saveas(gcf,fig_name,'png');
end
%}
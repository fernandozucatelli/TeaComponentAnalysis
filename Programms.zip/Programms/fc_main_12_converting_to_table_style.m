%% fc_main_12_converting_to_table_style
%%%%%%%%%%%%%
% help fc_main_12_converting_to_table_style
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to convert the intermediate table style into the final style
%%%%%%%%%%%%%
% version 01: 2020-01-01 -- Creation (ISO8601)
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_12_converting_to_table_style(excel_data_folder, file_to_load_sample, ...
    file_to_load_style)
%% Naming of all inside folders
programms_folder = pwd;
%% Go to folder
cd(excel_data_folder);
%% Load file -- main_11
file_to_load_sample = sprintf('%s.mat',file_to_load_sample);
file_to_load_style = sprintf('%s.mat',file_to_load_style);
load(file_to_load_sample);
%% Parameters
n_amostras = size(exp_cell,1);
linhas = size(new_super_tab,1);
pos_amostra = 5;
base_columns = 2; % It should be 3 with the colum with the names
%% Table as cell
base_tab_cell = cell(linhas,base_columns + 2*n_amostras);
%% main
% j: counter of the new table; r: counter of repetitions
j = 1;
for k = 1:linhas
    if k >= 2 && strcmp(new_super_tab{k,2},new_super_tab{k-1,2})
        j = j - 1;
    end
    base_tab_cell(k,:) = {'--'};
    pos = 1;
    amostra = exp_cell{pos}{1}(1:end-5);
    while pos <= n_amostras && ~strcmp(new_super_tab{k,pos_amostra}, amostra)
        pos = pos + 1;
        amostra = exp_cell{pos}{1}(1:end-5);
    end
    if ~strcmp(char(base_tab_cell(j,1)),'--')
        base_tab_cell(j,1) = {sprintf('%s/%s', char(base_tab_cell(j,1)), ...
            char(new_super_tab(k,1)))};
    else
        base_tab_cell(j,1:base_columns) = new_super_tab(k,1:base_columns);
    end
    base_tab_cell(j,base_columns + 2*pos-1:base_columns + 2*pos) = new_super_tab(k,3:4);
    j = j + 1;
end
%% Screen and remotion of extra cells
base_tab_cell = base_tab_cell(1:j-1,:);
%% Headers
base_header = exp_cell{1}{2}(4:5);
sample_header = cell(1,base_columns + n_amostras);
sample_header(1:base_columns) = {' ', ' '};
sample_word_header = cell(1,base_columns + 2*n_amostras);
sample_word_header(1:base_columns) = {' ', ' '};
repeted_header = cell(1,base_columns + 2*n_amostras);
repeted_header(1:base_columns) = exp_cell{1}{2}(2:3);
for k = 1:n_amostras
    amostra = exp_cell{k}{1}(1:end-5);
    sample_header{base_columns + k} = sprintf('\\multicolumn{2}{c}{%s}',amostra);
    sample_word_header(base_columns + 2*k-1:base_columns + 2*k) = [{amostra}, {''}];
    repeted_header(base_columns + 2*k-1:base_columns + 2*k) = base_header;
end
%% save
save(file_to_load_style,'sample_word_header','sample_header','repeted_header',...
    'base_tab_cell','base_columns','n_amostras');
%% Return to Programms folder
cd(programms_folder);
end
%% fc_main_03_graphs_and_colors
%%%%%%%%%%%%%
% help fc_main_03_graphs_and_colors
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to plot the graphs of all colors from a given sample in separated
%   subplots
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 07.12.2019 -- Renamed from: script_graphs_and_colors
%   to: fc_main_03_graphs_and_colors
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
% version 03: 2020-02-13 -- Revision with Roberta
%%%%%%%%%%%%%
%% algorithm
function fc_main_03_graphs_and_colors(path_all_data_folder, all_data_folder,...
    passos, folder_filter, pasta_figura, fig_base_name, aux_limite, labels)
%% Naming of all inside folders
new_mat_folder = 'only_data_mat';
programms_folder = pwd;
%% Fixed filters
mat_filter = {'.mat'}; % Load all
%% Load all txt file of a folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Loop for all folders
for j = 1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    cd(go_to_folder);
    %% Load list of files -- go to folder and come back
    cd(new_mat_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,mat_filter);
    cd(programms_folder);
    %% Parameters
    tipo = folder(end-1:end); % force naming as "folder_loteXY".
    titulo = sprintf('%s "%s"', labels{3}, tipo); % Input Sample
    %% Loop
    L = length(filelist);
    total_linhas_subplot = min(L,aux_limite);
    for p = 1:length(passos)
        aux = 0; cont_fig = 1;
        figure(10*p + cont_fig);
        set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
        %%
        for k = 1:L
            aux = aux + 1;
            if aux > aux_limite
                aux = 1; cont_fig = cont_fig + 1;
                figure(10*p + cont_fig);
                set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
            end
            % === Carregar para os an�lise
            file_name = sprintf('%s/%s/%s', go_to_folder, new_mat_folder, char(filelist(k)));
            load(file_name);
            if ~contains(folder,'00')
                pos = 100*ceil(total_linhas_subplot/p) + 10*p + aux;
                subplot(pos);
                farbe = fc_get_color_to_graph(cor);
                plot(M(:,1),M(:,3),'Color', farbe);
                v = axis; set(gca,'xtick',v(1):passos(p):v(2)); grid on;
                set(gca,'TickLength',[0,0]);
                leg = legend(file_name, 'Location',char(labels{4}));
                leg.Interpreter = 'none';
                leg.Box = char(labels{5});
            end
        end
    end
    %% Legends
    for p = 1:length(passos)
        for c = 1:cont_fig
            figure(10*p + c);
            pos = 100*ceil(total_linhas_subplot/p) + 10*p + 1;
            h1 = subplot(pos);
            if c > 1 && c == cont_fig
                resto = mod(L,aux_limite);
            else
                resto = total_linhas_subplot;
            end
            pos = 100*ceil(total_linhas_subplot/p) + 10*p + resto;
            h2 = subplot(pos);
            p1 = get(h1,'Position');
            p2 = get(h2,'Position');
            height = p1(2)+p1(4)-p2(2);
            axes('Position',[p1(1) p2(2) p2(3) height],'Visible','off');
            xl = xlabel(char(labels{1}),'Visible','on'); % Input
            ylabel(char(labels{2}),'Visible','on'); % Input
            if p == 2
                xl.Position = [3.5*p1(3), xl.Position(2:end)];
            end
            t = title(sprintf('%s: fig %02d / %02d ',titulo,c,cont_fig),'Visible','on');
            if  p == 2
                t.Position = [3.5*p1(3), t.Position(2:end)];
            end
            hold off;
        end
    end
    %% Creating a folder and saving in it
    pasta_figura_folder = sprintf('%s/%s', go_to_folder, pasta_figura);
    if ~exist(pasta_figura_folder, 'dir'); mkdir(pasta_figura_folder); end
    for p = 1:length(passos)
        for c = 1:cont_fig
            fig_name = sprintf('%s/%s_lote_%s_style_%d_count_%d', pasta_figura_folder, ...
                fig_base_name,tipo,p,c);
            saveas(figure(10*p + c),fig_name,'png');
        end
    end
    close all;
end
end
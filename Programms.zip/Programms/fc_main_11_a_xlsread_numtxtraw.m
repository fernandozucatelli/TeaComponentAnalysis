%% fc_main_11_a_xlsread_numtxtraw
%%%%%%%%%%%%%
% help fc_main_11_a_xlsread_numtxtraw
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to load all data from Excel spreadsheets into matlab matrices and
% applying the methods of analysis
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%%
% version 01: 30.11.2019 -- Creation
% version 02: 20.12.2019 -- Updating to a new form of extraction
%   28.12.2019 -- Update save file name
% version 03: 2020-01-01 -- Replacing Tex Table Creation.
% version 04: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_11_a_xlsread_numtxtraw(excel_data_folder, sample_name, file_to_load_sample)
programms_folder = pwd;
file_to_load_sample = sprintf('%s.mat',file_to_load_sample);
%% Go to folder
cd(excel_data_folder);
%% Load all .xls and .xslx spreadsheets and converting them into .mat files
extension = {'.xlsx'};
filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,extension);
exp_cell = cell(size(filelist,1),1);
ord = [11, 12, 1, 5, 10];
for k = 1:length(filelist)
    filename = char(filelist(k));
    amostra = filename(1:end-5);
    [num,txt,raw] = xlsread(filename);
    header_cell = [raw(1,ord), sample_name];
    x = round(0.001*num(:,ord(3)),1);
    dados_cell = {txt(2:end,ord(1)), num(:,ord(2)), x, ...
        txt(2:end,ord(4)), num(:,ord(5)), amostra};
    exp_cell{k} = {filename; header_cell; dados_cell};
end
%% Contar linhas m�ximas para super tabela
N = 0;
for k = 1:length(filelist)
    N = N + size(exp_cell{k}{3}{:,1},1);
end
%% Unifica��o
super_tab_cell = cell(N,6);
N = 0;
for k = 1:length(filelist)
    M = size(exp_cell{k}{3}{:,1},1);
    for j = [1,4]
        super_tab_cell(N + 1:N + M,j) = exp_cell{k}{3}{j};
    end
    for j = [2,5]
        for i = 1:M
            x = sprintf('%.0f', exp_cell{k}{3}{j}(i));
            super_tab_cell(i + N,j) = {x};
            % super_tab_cell(i + N,j) = {exp_cell{k}{3}{j}(i)};
        end
    end
    for j = 3
        for i = 1:M
            x = sprintf('%.1f', exp_cell{k}{3}{j}(i));
            super_tab_cell(i + N,j) = {x};
        end
    end
    for j = 6
        for i = 1:M
            super_tab_cell(i + N,j) = {exp_cell{k}{3}{j}};
        end
    end
    N = N + M;
end
%% Sort por ordem de reten��o
[~, I] = sort(super_tab_cell(:,3));
new_super_tab = super_tab_cell(I,2:end); % BATATA
%% save
save(file_to_load_sample,'exp_cell','super_tab_cell','new_super_tab');
%% Return to Programms folder
cd(programms_folder);
end
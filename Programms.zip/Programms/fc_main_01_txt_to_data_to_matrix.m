%% fc_main_01_txt_to_data_to_matrix
%%%%%%%%%%%%%
% help fc_main_01_txt_to_data_to_matrix
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to get all .txt from the espectroscopy and convert them into a
%   new .txt only with the desired data inside and then transform them
%   again into a matrix.
% The transformation into the same size matrix necessary to final
%   evaluation is made in another separeted script.
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 30.11.2019 -- Creation
% version 02: 02.12.2019 -- Updating to load original data from another
%   folder
%   Auxiliary have also been update
% version 03: 06.12.2019 -- Renamed from: script_carregar_txt_matriz
%   to: fc_main_01_txt_to_data_to_matrix
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
% version 03: 20.12.2019 -- Update only_figure to lote00
% version 04: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_01_txt_to_data_to_matrix(path_all_data_folder, all_data_folder,...
    pattern, folder_filter, passo, labels, flag_base_figures)
%% Naming of all inside folders
new_txt_folder = 'only_data_txt';
new_mat_folder = 'only_data_mat';
new_fig_folder = 'only_figures';
programms_folder = pwd;
%% Fixed filters
txt_filter = {'.txt'};
mat_filter = {'.mat'};
%% Load all txt file of a folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Loop for all folders
for j = 1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    cd(go_to_folder);
    %% Creating folders to store new files
    if ~exist(new_txt_folder,'dir'); mkdir(new_txt_folder); end
    if ~exist(new_mat_folder,'dir'); mkdir(new_mat_folder); end
    if ~exist(new_fig_folder,'dir'); mkdir(new_fig_folder); end
    %% Creating list of files
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,txt_filter);
    filelist = filelist(2:end); % Remove entry: 'allFilesName.txt'
    %% Come back to folder with programms
    cd(programms_folder);
    %% all local folders
    new_txt_folder_lote = sprintf('%s/%s', go_to_folder,new_txt_folder);
    new_mat_folder_lote = sprintf('%s/%s', go_to_folder,new_mat_folder);
    new_fig_folder_lote = sprintf('%s/%s', go_to_folder,new_fig_folder);
    %% main loop -- Extracting data to txt and to matrix
    for k = 1:length(filelist)
        file_name_ext = char(filelist(k));
        % new_txt
        fc_single_file_analysis(go_to_folder, new_txt_folder_lote, file_name_ext, pattern);
        % txt_to_matrix
        fc_single_data_file_to_matrix(new_txt_folder_lote, new_mat_folder_lote, file_name_ext);
    end
    if flag_base_figures == 1
        %% main loop -- Load matrix to generate graphs
        cd(new_mat_folder_lote); % Moving to folder with the matrices
        filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,mat_filter);
        cd(programms_folder); % Moving back to original folder
        %% Carregar para os gr�ficos
        for k = 1:length(filelist)
            file_name = char(filelist(k));
            load_name = sprintf('%s/%s',new_mat_folder_lote,file_name);
            load(load_name);
            fc_graphs(file_name, M, passo, new_fig_folder_lote, labels, cor);
        end
    end
end
toc
end
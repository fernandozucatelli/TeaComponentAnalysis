%% fc_main_09_b_table_file_MSWord
%%%%%%%%%%%%%
% help fc_main_09_b_table_file_MSWord
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to create the MSWord file with the desired table
%%%%%%%%%%%%%
% version 01: 2020-03-01 -- Creation (ISO8601)
%%%%%%%%%%%%%
%% algorithm
function fc_main_09_b_table_file_MSWord(path_all_data_folder, all_data_folder,...
    folder_filter, filtered_mat_folder, file_to_load_name,...
    DocReport_folder, DocName_base, TableCaptions)
%% Programm folders
programms_folder = pwd;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Create table folder
if ~exist(DocReport_folder,'dir'); mkdir(DocReport_folder); end
cd(DocReport_folder);
%% Return to Programms folder
TitleStyleName = TableCaptions{1};
LegendStyleName =  TableCaptions{3};
new_label =  TableCaptions{4};
separator =  TableCaptions{5};
%% main
for q = 1:length(folders_list)
    folder = char(folders_list(q));
    go_to_folder = sprintf('%s/%s/%s/%s',path_all_data_folder,all_data_folder, ...
        folder, filtered_mat_folder);
    cd(go_to_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,{file_to_load_name});
    %% Naming File
    % Do not use ".docx".
    DocName = sprintf('%s_%s',DocName_base,folder);
    DocName = fc_lib_backup_filename(DocName);
    CurDir = DocReport_folder;
    WordFileName = sprintf('%s.doc',DocName);
    fprintf('Started -- Iniciado\n');
    %% Create File
    FileSpec = fullfile(CurDir,WordFileName);
    flag_visible = 0;
    [ActXWord,WordHandle] = fc_lib_msword_start_Word(FileSpec,flag_visible);
    ActXWord.CaptionLabels.Add(new_label);
    TitleString = sprintf('%s', folder);
    TitleString = strrep(TitleString,'_',' ');
    fc_lib_msword_write_text(ActXWord,TitleString,TitleStyleName,[1,2],1);
    %% Page Break
    ActXWord.Selection.InsertBreak;
    for p = 1:2:length(filelist)
        load_name = char(filelist(p));
        load(load_name);
        load_name = char(filelist(p+1));
        load(load_name);
        %% Writting Caption
        TableTitleString = sprintf('%s %s.', TableCaptions{2}, caption_name);
        ActXWord.Selection.InsertCaption(new_label, separator, '', 0, false);
        fc_lib_msword_write_text(ActXWord,TableTitleString,LegendStyleName,[0,1],1); %2 enters after text
        %% Formatted Table
        [l,c] = size(base_tab_cell_header);
        tab_align = 'wdAlignRowCenter';
        text_align = 1;
        col_lines = '';
        row_lines = 2;
        rowMerge = '';
        fc_lib_msword_create_table(ActXWord,l,c,base_tab_cell_header,0,...
            tab_align,text_align,colMerge,rowMerge,col_lines,row_lines);
        %% Page Break
        ActXWord.Selection.InsertBreak;
    end
    %% Save and close
    fc_lib_msword_close_Word(ActXWord,WordHandle,FileSpec);
    fprintf('Finished -- Conclu�do\n');
end
%% Return to Programms folder
cd(programms_folder);
end
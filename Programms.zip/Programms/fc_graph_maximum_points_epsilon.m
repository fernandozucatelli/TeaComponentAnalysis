%% fc_graph_maximum_points_epsilon
%%%%%%%%%%%%%
% help fc_graph_maximum_points_epsilon
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to plot the spectogram without filtering and with each given
% filter value. It also saves each figure with the respective filter value
% in the name and in the title
%%%%%%%%%%%%%
% flag_fig -- determines behavior and types of graph to be plotted
% 0: No figures saved
% 1: Intensity order -- filtered out
% 2: Intensity order -- filtered to 0
% 3: Temporal order -- filtered out
% 4: Temporal order -- filtered to 0
% 5: All figures
%%%%%%%%%%%%% Sort library
% fc_lib_sort_search_filtering_pts_dist_eps
%%%%%%%%%%%%%
% version 01: 09.12.2019 -- Creation
% version 02: 10.12.2019 -- Update to deal with new type of entry and flag
%   to select if the plot of figure is desired.
% version 03: 2020-02-14 -- Updating flag_fig to enable selection between
%   four variations of the graph.
%%%%%%%%%%%%%
%% algorithm
function coordenadas_cell = fc_graph_maximum_points_epsilon(dados, value_filter, pts_searched, epsilon, ...
    passo, dy, fig_save_path, flag_fig, labels)
%% Carregar dados
M = dados{1};
file_name = dados{1 + length(value_filter) + 1};
cor = dados{1 + length(value_filter) + 2};
farbe = fc_get_color_to_graph(cor);
dko = [229 95 20]/255; % Dark Orange
prp = [210 14 197]/255; % Dark Purple
%% Cell to store all coordinates to max and min analysis
coordenadas_cell = cell(1,length(value_filter));
%% Loop for filtered data
for f = 1:length(value_filter)
    %% Filtering
    filtro = value_filter(f);
    M_0 = fc_filtering_for_zero(M,filtro);
    M_f = dados{f+1};
    %% Sorting for maximum
    [S, I] = sort(M_f(:,3));
    %% Filtering maximum peaks closer than epsilon
    tam = length(I);
    pts = fc_lib_sort_search_filtering_pts_dist_eps(M_f(:,1), I, pts_searched, tam, epsilon);
    while pts(end,1) == 0
        pts = pts(1:end-1,:);
    end
    coord = [pts(:,1),S(end-pts(:,2))];
    %% Sorting for temporal order
    [R, J] = sort(pts(:,1));
    %% Plotting figures    
    if flag_fig > 0
        if flag_fig == 1 || flag_fig == 5
            %% plot data maximum points -- intensity -- filtered
            f1 = figure(1);
            f1 = fc_plot_maxima_pts(f1,coord,labels,file_name,filtro);
            hold all;
            f1 = fc_plot_filtered(f1,M,M_f,farbe);
            f1 = fc_set_param(f1, passo);
            f1 = fc_str_pts_intensity(f1,pts,S,dy,dko);
        end
        if flag_fig == 2 || flag_fig == 5
            %% plot data maximum points -- intensity -- M_0
            f2 = figure(2);
            f2 = fc_plot_maxima_pts(f2,coord,labels,file_name,filtro);
            hold all;
            plot(M_0(:,1),M_0(:,3), 'Color',farbe,'LineStyle','-');
            f2 = fc_set_param(f2, passo);
            f2 = fc_str_pts_intensity(f2,pts,S,dy,dko);
        end
        if flag_fig == 3 || flag_fig == 5
            %% plot data maximum points -- temporal -- filtered
            f3 = figure(3);
            f3 = fc_plot_maxima_pts(f3,coord,labels,file_name,filtro);
            hold all;
            f3 = fc_plot_filtered(f3,M,M_f,farbe);
            f3 = fc_set_param(f3, passo);
            f3 = fc_str_pts_time(f3,pts,S,R,J,dy,prp);
        end
        if flag_fig == 4 || flag_fig == 5
            %% plot data maximum points -- temporal -- filtered
            f4 = figure(4);
            f4 = fc_plot_maxima_pts(f4,coord,labels,file_name,filtro);
            hold all;
            plot(M_0(:,1),M_0(:,3), 'Color',farbe,'LineStyle','-');
            f4 = fc_set_param(f4, passo);
            f4 = fc_str_pts_time(f4,pts,S,R,J,dy,prp);
        end
        %% Save figures
        fig_save_name = sprintf('%s/fig_pts_max_f1_%s_filter_%02d', ...
            fig_save_path, file_name, filtro);
        if flag_fig == 1 || flag_fig == 5
            saveas(f1,fig_save_name,'png');
        end
        if flag_fig == 2 || flag_fig == 5
            saveas(f2,strrep(fig_save_name,'pts_max_f1','pts_max_f2'),'png');
        end
        if flag_fig == 3 || flag_fig == 5
            saveas(f3,strrep(fig_save_name,'pts_max_f1','pts_max_f3'),'png');
        end
        if flag_fig == 4 || flag_fig == 5
            saveas(f4,strrep(fig_save_name,'pts_max_f1','pts_max_f4'),'png');
        end
        close all;
    end
    %% max and min interval of each peak.
    %hold all;
    [~, N] = sort(M_0(:,3));
    indices_maximos = N(end-pts(:,2));
    minimos = zeros(length(indices_maximos),1);
    maximos = zeros(length(indices_maximos),1);
    for k = 1:length(indices_maximos)
        x = indices_maximos(k);
        while M_0(x,3) > M_0(x-1,3) && M_0(x,3) > 0
            x = x - 1;
        end
        minimos(k) = x;
        x = indices_maximos(k);
        while M_0(x,3) > M_0(x+1,3) && M_0(x,3) > 0
            x = x + 1;
        end
        maximos(k) = x;
    end
    % plot(M_0(indices_maximos,1),M_0(indices_maximos,3),'mp');
    % plot(M_0(minimos,1),M_0(minimos,3),'rs','MarkerSize',14); hold all;
    % plot(M_0(maximos,1),M_0(maximos,3),'bh','MarkerSize',14);
    %% Coordinates to create table
    coordenadas_cell{1,f} = [coord, minimos, maximos, J];
end
save_name = sprintf('%s/pts_max_%s.mat', fig_save_path, file_name);
save(save_name,'coordenadas_cell');
end
%%
function fh = fc_plot_maxima_pts(fh,coord,labels,file_name,filtro)
fh = figure(fh);
plot(coord(:,1),coord(:,2), 'o','MarkerSize',12);
xlabel(char(labels{1})); % Input
ylabel(char(labels{2})); % Input
titulo = sprintf('%s: %s = %2d%%',file_name,char(labels{3}),filtro); % Input
t = title(titulo,'Interpreter','none','HorizontalAlignment','Left');
t.Position = [0 t.Position(2:end)];
end
function fh = fc_set_param(fh, passo)
set(gcf, 'Units','normalized','OuterPosition',[0.02 0.05 0.9 0.88]);
v = axis; set(gca,'xtick',v(1):passo:v(2)); grid on;
set(gca,'TickLength',[0,0]);
end
function fh = fc_plot_filtered(fh,M,M_f,farbe)
fh = figure(fh);
plot(M(:,1),M(:,3), 'Color',farbe,'LineStyle','--');
plot(M_f(:,1),M_f(:,3), 'Color',farbe,'LineStyle',':','LineWidth',1.5);
end
%% Intensity order
function fh = fc_str_pts_intensity(fh,pts,S,dy,cor)
fh = figure(fh);
for k = 1:size(pts,1)
    % str = sprintf('P%02d: (%g, %g)', k,pts(k,1),S(end-pts(k,2)));
    % str = sprintf('%d: %.1f', k,pts(k,1));
    str = sprintf('%d', k);
    text(pts(k,1),S(end-pts(k,2)) + dy, str,'Color', cor,...
        'FontWeight', 'Bold');
end
end
%% Time order
function fh = fc_str_pts_time(fh,pts,S,R,J,dy,cor)
for k = 1:size(pts,1)
    str = sprintf('%d', k);
    text(R(k),S(end-pts(J(k),2)) + dy, str,'Color', cor,...
        'FontWeight', 'Bold');
end
end
function [M, cor, sabor, marca, estado] = fc_single_data_file_to_matrix(new_txt_folder, new_mat_folder, file_name_ext)
new_arquivo = sprintf('%s/novo_%s',new_txt_folder,file_name_ext);
fid = fopen(new_arquivo ,'r');
%% Creating the cell from the data-only file
% The format is predefined
% In a new version it can be an input to the function
C = textscan(fid, '%.3f %.3f %.3f');
fclose(fid);
%% Identify Color and Brand
[cor, sabor, marca, estado] = fc_extract_prop(file_name_ext);
%% Creating the matrix and saving it
M = cell2mat(C);
file_name = file_name_ext(1:end-4); % Remove extension
save_name = sprintf('%s/mat_novo_%s.mat',new_mat_folder,file_name);
save(save_name,'C','M','cor','sabor', 'marca', 'estado','file_name');
end
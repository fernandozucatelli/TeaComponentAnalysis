%% fc_main_22_table_style_final_tex
%%%%%%%%%%%%%
% help fc_main_22_table_style_final_tex
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to write a LaTeX table from the final table style data
%%%%%%%%%%%%%
% version 01: 2020-01-01 -- Creation (ISO8601)
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_22_table_style_final_tex(excel_data_folder, caption_name, ...
    tex_file, filter, file_to_load_sample)
%% Naming of all inside folders
programms_folder = pwd;
tex_file_name_path = tex_file{1};
tex_radical = 'input_longtab';
tab_name = sprintf('%s_%s',tex_radical,tex_file{2});
if ~exist(tex_file_name_path ,'dir'); mkdir(tex_file_name_path ); end
%% Go to folder
cd(excel_data_folder);
%% Load saved .mat file
file_to_load_sample = sprintf('%s.mat',file_to_load_sample);
load(file_to_load_sample);
%% Cell to Table -- header
h1 = fc_lib_latex_cell_to_tab_line(sample_header);
h2 = fc_lib_latex_cell_to_tab_line(repeted_header,'\hline');
h = char(h1,h2);
tb = fc_lib_latex_cell_to_tab_line(base_tab_cell);
h_tb = char(h,tb);
h_tb = fc_lib_latex_ponto_para_virgula(h_tb);
%% save tex table
total_cols = base_columns + 2*n_amostras;
format = repmat('c',1,total_cols);
caption_label = {caption_name, tab_name};
tabela_style_1 = fc_lib_latex_add_tabular_longtable(format,h_tb,1,caption_label);
str_ext = '.tex';
tex_file_name = sprintf('%s/%s',tex_file_name_path, tab_name);
fc_lib_save_file_extensao(tex_file_name, str_ext, tabela_style_1);
%% Replacing non-desired values
cd(tex_file_name_path);
% input has negative signal therefore the substituition does not mistake it with
%   any number of min/max part of the table
input = {'%', '_','\%\%', '#', '$$', strrep(tab_name,'_','\_')};
output = {'\%', '\_', '%%', '', '', tab_name};
encod = 'ISO-8859-1';
flag_copy = 0;
fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);
%% Return to Programms folder
cd(programms_folder);
end
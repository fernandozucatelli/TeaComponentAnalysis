%% file_name = 'CVD_BR_CE_SD'
%%
figure;
plot(S,I); grid on; hold all;
plot(coord(:,2),I(end-pts(:,2)), 'o', 'MarkerSize', 12);
xlabel(labels(2)); ylabel('Position of the sample in the vector');
title(file_name, 'Interpreter','none');
%%
figure;
plot(S,M_f(I,1)); grid on; hold all;
plot(coord(:,2),coord(:,1), 'o', 'MarkerSize', 12);
xlabel(labels(2)); ylabel(labels(1));
title(file_name, 'Interpreter','none');
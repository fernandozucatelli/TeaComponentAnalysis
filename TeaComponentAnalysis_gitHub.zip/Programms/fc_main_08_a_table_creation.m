%% fc_main_08_a_table_creation
%%%%%%%%%%%%%
% help fc_main_08_a_table_creation
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to sort experimental data and max point into a cell
%%%%%%%%%%%%%
% version 01: 2020-03-01 -- Creation (ISO8601)
% version 02: 2020-03-14 -- Added decimal displacement
%%%%%%%%%%%%%
%% algorithm
function fc_main_08_a_table_creation(path_all_data_folder, all_data_folder,...
    folder_filter, filtered_mat_folder, new_fig_max_folder, file_all_data, ...
    file_to_load_name, decimal)
%% Programm folders
programms_folder = pwd;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Return to Programms folder
cd(programms_folder);
%% main
for q = 1:length(folders_list)
    %% Load data_all_M_filtered
    folder = char(folders_list(q));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    load_name = sprintf('%s/%s/%s', go_to_folder, filtered_mat_folder, file_all_data);
    load(load_name);
    
    all_pts_max_mat = sprintf('all_pts_max_%s.mat',folder);
    load_name = sprintf('%s/%s/%s', go_to_folder, new_fig_max_folder,all_pts_max_mat);
    load(load_name);
    
    %% main
    L = length(value_filter);
    P = length(value_filter)+2;
    for j = 1:L
        n_amostras = size(all_coordenadas_cell,1);
        amostras_name = cell(n_amostras,1);
        acc = 0;
        for i = 1:n_amostras
            acc = acc + size(all_coordenadas_cell{i,j},1);
            amostras_name(i) = {all_M_filtered{i,P}};
        end
        super_tab_cell = cell(acc,6);
        super_tab_mat = zeros(acc,4);
        u = 1;
        for i = 1:size(all_M_filtered,1)
            [A, ~] = size(all_coordenadas_cell{i,j});
            M = all_M_filtered{i,1};
            x = all_coordenadas_cell{i,j};
            S = x(:,5); x = x(S,:);
            
            super_tab_mat(u:u+A-1,1:2) = x(:,1:2);
            super_tab_mat(u:u+A-1,3) = M(x(:,3),1);
            super_tab_mat(u:u+A-1,4) = M(x(:,4),1);
            for k = u:u+A-1
                super_tab_cell(k,5) = {sprintf('%.0f', k-u+1)};
                super_tab_cell(k,6) = {all_M_filtered{i,P}};
            end
            u = u + A;
        end
        %% Sort matrix
        [~, I] = sort(super_tab_mat(:,1));
        %% Creating char array cell
        for i = 1:size(super_tab_cell,1)
            for k = 1:4
                if k ~= 1
                    x = sprintf(char(decimal(2)), super_tab_mat(i,k));
                else
                    x = sprintf(decimal{1}, super_tab_mat(i,k));
                end
                super_tab_cell(i,k) = {x};
            end
        end
        %% Apllying sorted list from the matrix into the cell
        ord = [1,3:4,5,2,6];
        new_super_tab = super_tab_cell(I,ord);
        %% Caption name
        caption_name = sprintf('%s filter %02d',folder,value_filter(j));
        caption_name = strrep(caption_name, '_',' ');
        caption_name = strrep(caption_name, '.mat','.');
        %% save -- carregar em outra fun��o para construir as tabelas?
        file_to_load_mat = sprintf('%s_%s_filter_%02d.mat',...
            file_to_load_name,folder,value_filter(j));
        save_name = sprintf('%s/%s/%s', go_to_folder, filtered_mat_folder,file_to_load_mat);
        save(save_name,'super_tab_cell','new_super_tab','n_amostras',...
            'amostras_name','caption_name','value_filter');
    end
end
end
%% Auxiliar plot
%         M = all_M_filtered{i,j};
%         plot(M(:,1),M(:,3));
%         hold all;
%         plot(super_tab_cell(:,1),super_tab_cell(:,2),'o');
%         plot(M(super_tab_cell(:,3),1),M(super_tab_cell(:,3),3),'s');
%         plot(M(super_tab_cell(:,4),1),M(super_tab_cell(:,4),3),'p');

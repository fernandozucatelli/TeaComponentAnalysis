%% main_10_start_analysis_02
%%%%%%%%%%%%%
% help main_10_start_analysis_02
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Second part of Tea Components Analysis Code
%%%%%%%%%%%%%
% version 01: 2020-02-16 -- Creation (ISO8601)
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc; tic;
% mains = [1 0 1 1 1 1];
mains = [0 0 0 0 0 1];
%% ============ General
excel_data_folder = 'C:\Users\FHZ\Dropbox\Projeto_Roberta_Nogueira_Matlab\data_for_analysis_excel_gcms_table';
file_to_load_sample = 'results_table_sample';
file_to_load_style = 'results_table_style';
caption_name = 'Tabela com os resultados de todos os lotes -- ordenados por tempo de reten��o.';
label_name = 'input_longtab_results_retention_time_02';
tex_file_name_path = 'C:\Users\FHZ\Dropbox\Projeto_Roberta_Nogueira_Matlab\Relatorio';
%% ============
if mains(1) == 1
    %% Parameters
    sample_name = 'Amostra';
    %% Naming of all inside folders
    fc_main_11_a_xlsread_numtxtraw(excel_data_folder, sample_name, file_to_load_sample);
end
%% ============
if mains(2) == 1
    ord = [11, 12, 1, 5, 10];
    fc_main_11_b_readtable(excel_data_folder, ord);
end
%% ============
if mains(3) == 1
    fc_main_12_converting_to_table_style(excel_data_folder, file_to_load_sample, ...
        file_to_load_style);
end
%% ============
if mains(4) == 1
    
    tex_file_name_1_sufix = 'results_retention_time_01';
    tex_file_name_2_sufix = 'results_retention_time_02';
    tex_file = {tex_file_name_path, tex_file_name_1_sufix, tex_file_name_2_sufix};
    
    filter = {'retention_time_01','retention_time_02'};
    
    fc_main_21_table_style_intermediate_tex(excel_data_folder, tex_file, ...
        filter, file_to_load_sample, caption_name, label_name);
end
%% ============
if mains(5) == 1
    filter = {'retention_time_03'};
    file_to_load_sample = 'results_table_style';
    
    tex_tab_name_1_sufix = 'results_retention_time_03';
    tex_file = {tex_file_name_path, tex_tab_name_1_sufix};
    
    fc_main_22_table_style_final_tex(excel_data_folder, caption_name, ...
        tex_file, filter, file_to_load_sample);
end
%% ============
if mains(6) == 1
    DocReport_folder = 'C:\Users\FHZ\Dropbox\Projeto_Roberta_Nogueira_Matlab\Doc_Tables';
    DocName_base = 'tabelas_1_E_2';
    
    Style = 'T�tulo 1'; % Change for your language Title.
    TitleString = 'Behold my power';
    TextString_1 = 'Tabela 1 -- Gerada automaticamente pelo Matlab';
    TextString_2 = 'Tabela 2: Gerada automaticamente pelo Matlab.';
    TableCaptions = {Style, TitleString, TextString_1, TextString_2};
    
    fc_main_23_cell_table_to_MSWord(excel_data_folder, file_to_load_style, ...
        DocReport_folder, DocName_base, TableCaptions);
end
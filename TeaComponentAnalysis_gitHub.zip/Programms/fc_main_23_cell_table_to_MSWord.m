%% fc_main_23_cell_table_to_MSWord
%%%%%%%%%%%%%
% help fc_main_23_cell_table_to_MSWord
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to write a MSWord table from the final table style data
%%%%%%%%%%%%%
% Source: Verify whole msword_library
%%%%%%%%%%%%%
% This code use the following function from my library
%   fc_lib_backup_filename
%%%%%%%%%%%%%
% version 01: 2020-01-01 -- Creation (ISO8601)
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_23_cell_table_to_MSWord(excel_data_folder, file_to_load_style, ...
    DocReport_folder, DocName_base, TableCaptions)
%% Naming of all inside folders
programms_folder = pwd;
%% Strings
Style = char(TableCaptions{1});
TitleString = char(TableCaptions{2});
TableCaption_1 = char(TableCaptions{3});
TableCaption_2 = char(TableCaptions{4});
%% Creating Folders to store DocTables
if ~exist(DocReport_folder,'dir'); mkdir(DocReport_folder); end
%% Go to folder
cd(excel_data_folder);
%% Load file -- main_12
file_to_load_style = sprintf('%s.mat', file_to_load_style);
load(file_to_load_style);
base_tab_cell_header = [sample_word_header; repeted_header; base_tab_cell];
colMerge = {1, [3,4; 5,6]};
[NoRows,NoCols] = size(base_tab_cell_header);
for i = 3:NoRows
    for j = 2:NoCols
        base_tab_cell_header(i,j) = {fc_lib_latex_ponto_para_virgula(char(base_tab_cell_header(i,j)),',')};
    end
end
%% Nome do arquivo
% Do not use ".docx".
DocName = fc_lib_backup_filename(DocName_base);
CurDir = pwd;
CurDir = strrep(CurDir,excel_data_folder,DocReport_folder);
WordFileName = sprintf('%s.doc',DocName);
fprintf('Started -- Iniciado\n');
%% Criar arquivo
FileSpec = fullfile(CurDir,WordFileName);
flag_visible = 0;
[ActXWord,WordHandle] = fc_lib_msword_start_Word(FileSpec,flag_visible);
%% Escrita -- T�tulo
fc_lib_msword_write_text(ActXWord,TitleString,Style,[1,2],1); %2 enters after text
%% Page Break
ActXWord.Selection.InsertBreak;
%% Escrita -- Tabela
Style = 'Normal';
fc_lib_msword_write_text(ActXWord,TableCaption_1,Style,[0,1],0,[0 1 0]);
fc_lib_msword_write_text(ActXWord,'',Style,[0,0],0,[0 0 0]);
%% Tabela 1
[l,c] = size(base_tab_cell);
tab_align = 'wdAlignRowLeft';
text_align = 2;
rowMerge = '';
col_lines = '';
row_lines = '';
fc_lib_msword_create_table(ActXWord,l,c,base_tab_cell,1,tab_align,text_align,...
    '', rowMerge, col_lines, row_lines);
%% Page Break
ActXWord.Selection.InsertBreak;
%% Escrita -- Tabela
Style = 'Normal';
fc_lib_msword_write_text(ActXWord,TableCaption_2,Style,[0,0],1);
%% Tabela 2
tab_align = 'wdAlignRowCenter';
text_align = 1;
row_lines = 2;
fc_lib_msword_create_table(ActXWord,NoRows,NoCols,base_tab_cell_header(1:NoRows,:),0,...
    tab_align,text_align,colMerge,rowMerge,col_lines,row_lines);
%% Salvar e fechar t�cnica com fun��o
fc_lib_msword_close_Word(ActXWord,WordHandle,FileSpec);
fprintf('Finished-- Conclu�do\n');
%% Return to Programms folder
cd(programms_folder);
end
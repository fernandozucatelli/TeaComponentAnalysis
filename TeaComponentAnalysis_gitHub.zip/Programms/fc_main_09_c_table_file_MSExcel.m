%% fc_main_09_c_table_file_MSExcel
%%%%%%%%%%%%%
% help fc_main_09_c_table_file_MSExcel
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% This function uses xlswrite1 to speed up the save process
% Matt Swartz (2020). xlswrite1 
% (https://www.mathworks.com/matlabcentral/fileexchange/10465-xlswrite1), 
% MATLAB Central File Exchange. Retrieved March 11, 2020.
%%%%%%%%%%%%%
% Function to create the MSExcel file with the desired table
%%%%%%%%%%%%%
% version 01: 2020-03-01 -- Creation (ISO8601)
% version 02: 2020-03-03 -- MSExcel spreadsheet is now created for folder
%   and the filter are different sheets inside it
%%%%%%%%%%%%%
%% algorithm
function fc_main_09_c_table_file_MSExcel(path_all_data_folder, all_data_folder,...
    folder_filter, filtered_mat_folder, file_to_load_name,...
    XlsReport_folder, XlsName_base)
%% Programm folders
programms_folder = pwd;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Create table folder
if ~exist(XlsReport_folder,'dir'); mkdir(XlsReport_folder); end
%% main
for q = 1:length(folders_list)
    folder = char(folders_list(q));
    go_to_folder = sprintf('%s/%s/%s/%s',path_all_data_folder,all_data_folder, ...
        folder, filtered_mat_folder);
    cd(go_to_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,{file_to_load_name});
    %% Naming file
    for p = 1:2:length(filelist)
        load_name = char(filelist(p));
        load(load_name);
        load_name = char(filelist(p+1));
        load(load_name);
        %% Writing Spreadsheet
        save_xls_name = sprintf('%s/%s_%s_%02d',XlsReport_folder,XlsName_base,folder,p);
        save_xls_name = fc_lib_backup_filename(save_xls_name);
        % xlswrite(save_xls_name,base_tab_cell_header,ceil(p/2),'B2');
        %% Create Excel for xlswrite1
        Excel = actxserver ('Excel.Application');
        File = strrep(save_xls_name,'/','\');
        if ~exist(File,'file')
            ExcelWorkbook = Excel.workbooks.Add;
            ExcelWorkbook.SaveAs(File,1);
            ExcelWorkbook.Close(false);
        end
        invoke(Excel.Workbooks,'Open',File);
        %% Writing Spreadsheet
        fprintf('%s\n',save_xls_name);
        % xlswrite(save_xls_name,base_tab_cell_header,1,'B2');
        xlswrite1(save_xls_name,base_tab_cell_header,1,'B2');
        %% Cleaning Excel
        invoke(Excel.ActiveWorkbook,'Save');
        Excel.Quit
        Excel.delete
        clear Excel;
    end
end
%% Return to Programms folder
cd(programms_folder);
end
%% Writing Spreadsheet -- ActiveX
% % e = actxserver('Excel.Application');
% % === Add a workbook.
% eWorkbook = e.Workbooks.Add;
% e.Visible = 1;
% % === Make the first sheet active.
% eSheets = e.ActiveWorkbook.Sheets;
% eSheet1 = eSheets.get('Item',1);
% eSheet1.Activate
% % === Put MATLAB data into the worksheet.
% A = [1 2; 3 4];
% eActivesheetRange = get(e.Activesheet,'Range','A1:ZZ1000000');
% eActivesheetRange.Value = A; % base_tab_cell_header;
% % === Read the data back into MATLAB, where array B is a cell array.
% % eRange = get(e.Activesheet,'Range','A1:B2');
% % B = eRange.Value;
% % === Convert the data to a double matrix. Use the following command if the cell array contains only scalar values.
% % B = reshape([B{:}],size(B));
% % === Save the workbook in a file.
% SaveAs(eWorkbook,save_xls_name)
% % === If the Excel program displays a dialog box about saving the file, select the appropriate response to continue.
% % === If you saved the file, then close the workbook.
% eWorkbook.Saved = 1;
% Close(eWorkbook);
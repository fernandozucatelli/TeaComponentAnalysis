%% fc_lib_sort_search_filtering_pts_dist_eps
%%%%%%%%%%%%%
% help fc_lib_sort_search_filtering_pts_dist_eps
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to filter the maximum of a sorted array that are distant from
% each other
% The v array MUST BE a sorted arrary. Check Example 01.
%%%%%%%%%%%%%
% Source: Link the source material when it is avaliable
%%%%%%%%%%%%%
% version 01: 03.12.2019 -- Creation
% version 02: 2020-02-15 -- Correction at pts(acc,:) = [x,k];
%   pts(acc,:) = [x,k-1];
%%%%%%%%%%%%% Example 01
% load('data_fc_lib_sort_search_filtering_pts_dist_eps.mat');
% B = A(A(:,2) >= 20,:);
% plot(A(:,1),A(:,2), '--b'); hold all;
% plot(B(:,1),B(:,2), ':b', 'LineWidth', 2);
% set(gcf,'Units','Normalized','Position',[0.05 0.05 0.9 0.85]);
% [S, I] = sort(B(:,2));
% pontos = 6; deep = 50; epsilon = 1;
% pts = fc_lib_sort_search_filtering_pts_dist_eps(B(:,1), I, pontos, deep, epsilon);
% while pts(end,1) == 0
%     pts = pts(1:end-1,:);
% end
% coord = [pts(:,1),S(end-pts(:,2))];
% plot(coord(:,1),coord(:,2), 'o','MarkerSize',12);
% for k = 1:size(pts,1)
%     str = sprintf('%d', k);
%     text(pts(k,1),S(end-pts(k,2)) + 5, str, 'FontWeight', 'Bold');
% end
%%%%%%%%%%%%%
%% algorithm
function pts = fc_lib_sort_search_filtering_pts_dist_eps(v, I, pontos, deep, epsilon)
if deep > size(v,1)
    error('deep > size(M,1). Searching more points than exist.');
end
pts = zeros(pontos,2);
acc = 1;
pts(acc) = v(I(end));
k = 2;
while k < deep && acc < pontos
    x = v(I(end-k+1));
    j = 1;
    while j <= acc && abs(pts(j,1) - x) > epsilon
        j = j + 1;
        if j > acc
            acc = acc + 1;
            pts(acc,:) = [x,k-1];
        end
    end
    k = k + 1;
end
end
function [cor, sabor, marca, estado] = fc_extract_prop(file_name_ext)
cor = file_name_ext(2:3);
sabor = file_name_ext(5:6);
marca = file_name_ext(8:9);
estado = file_name_ext(11:12);
end
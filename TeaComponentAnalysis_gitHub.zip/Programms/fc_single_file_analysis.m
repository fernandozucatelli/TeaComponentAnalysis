function fc_single_file_analysis(txt_folder, new_txt_folder, file_name_ext, pattern)
% new_txt_folder: folder to store new files
% file_name_ext: name of the old file and root for the new one
% pattern: string to be found as mark to start the extraction
%% Naming original and new files
new_arquivo = sprintf('novo_%s',file_name_ext);
file_name_ext = sprintf('%s/%s', txt_folder, file_name_ext);
file_data_txt = sprintf('%s', file_name_ext);
file_data_txt_new = sprintf('%s/%s', new_txt_folder,new_arquivo);
%% Opening old file to read and creating new file to write the desired data
fid1 = fopen(file_data_txt,'r');
fid2 = fopen(file_data_txt_new ,'w');
%% Main loop
% flag to inform that the next line must be copied
flag_i_found = 0;
while 1
    % === pega uma linha do arquivo - get a file line
    tline = fgetl(fid1);
    % === criterio de saida quando nao encontra mais linha - exit criterium and do not find a line
    if ~ischar(tline)
        break;
    end
    % strcmp(tline, 'Ret.Time	Absolute Intensity	Relative Intensity')
    if flag_i_found == 1
        fprintf(fid2, '%s\n', tline);
    end
    if contains(tline,pattern)
        flag_i_found = 1;
    end
end
%% Closing both file
fclose(fid1);
fclose(fid2);
end
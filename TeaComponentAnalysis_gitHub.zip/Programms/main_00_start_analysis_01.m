%% main_00_start_analysis_01
%%%%%%%%%%%%%
% help main_00_start_analysis_01
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% flag_fig -- determines behavior and types of graph to be plotted
% 0: No figures saved
% 1: Intensity order -- filtered out
% 2: Intensity order -- filtered to 0
% 3: Temporal order -- filtered out
% 4: Temporal order -- filtered to 0
% 5: All figures
%%%%%%%%%%%%%
% Script to call all functions of the first part of the package
%%%%%%%%%%%%%
% version 01: 2020-02-16 -- Creation (ISO8601)
%   2020-03-01 -- Added mains 08ab and 09abc.
%%%%%%%%%%%%% Example 01
% This is the example of usage of all functions fc_main from 01 to 07
%%%%%%%%%%%%%
%% algorithm
clear; close all; clc; tic;
% mains = [1 1 1 1 0 0 1 0 0 0 0 0];
% mains = [1 1 1 1 0 1 1 1 1 1 1 1];
% mains = [0 0 0 1 0 0 0 1 1 1 1 1]; % 4 8ab 9abc
% mains = [0 0 0 0 0 0 0 1 1 1 1 1]; % 8ab 9abc
% mains = [0 0 0 0 0 0 0 0 1 1 1 1]; % 8b 9abc
% mains = [0 0 0 0 0 0 0 0 0 0 1 1]; % 9bc
% mains = [0 0 0 0 0 0 0 0 0 0 0 1]; % 9c
%% ============ General
mains = [0 0 0 0 0 0 0 0 0 0 0 0];
path_all_data_folder = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab';
% all_data_folder = 'data_for_analysis';
all_data_folder = 'data_for_review';
%% ============
if mains(1) == 1
    pattern = 'Absolute';
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};
    passo = 2;
    labels = {'Tempo Reten��o [min]','Intensidade Relativa'};
    % labels = {'Retention Time [min]','Relative Intensity'};
    flag_base_figures = 1;
    fig_format = 'eps2c'; % 'eps2c'; 'png';

    fc_main_01_txt_to_data_to_matrix(path_all_data_folder, all_data_folder,...
        pattern,folder_filter,passo,labels, flag_base_figures, fig_format);
    close all;
end
%% ============
if mains(2) == 1
    %value_filter = [1 5 10 20];
    value_filter = [1 20];
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};

    fc_main_02_matrix_filtering(path_all_data_folder, all_data_folder,...
        value_filter,folder_filter);
end
%% ============
if mains(3) == 1
    passos = [2 4]; % 2 4 % Input
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};
    % pasta_figura = 'Figures_Comparing_Samples'; % Input
    % pasta_figura = 'Figures_Comparing_Samples_EN_artigo'; % Input
    pasta_figura = 'Figures_Comparing_Samples_EN_artigo_eps'; % Input
    fig_base_name = 'fig_subplot_compare';
    aux_limite = 6; % Input
    % labels = {'Tempo Reten��o [min]','Intensidade Relativa','Amostra',...
    %    'NorthWest','off'}; % 'Best'.
    labels = {'Retention Time [min]','Relative Intensity','Sample',...
        'NorthWest','off'};
    fig_format = 'eps2c'; % 'eps2c'; 'png';

    fc_main_03_graphs_and_colors(path_all_data_folder, all_data_folder,...
        passos, folder_filter, pasta_figura, fig_base_name, aux_limite, ...
        labels, fig_format);
end
%% ============
if mains(4) == 1
    %folder_filter = {'lote'};
    folder_filter = {'lote15'};
    %folder_filter = {'lote09','lote10'};

    pts_searched = 10;
    epsilon = 0.5;
    passo = 2;
    dy = 5;
    parameters_search = [pts_searched, epsilon, passo, dy];

    % labels = {'Tempo Reten��o [min]','Intensidade Relativa', 'filtro'};
    labels = {'Retention Time [min]', 'Relative Intensity', 'filter'};
    flag_fig = 5;
    fig_format = 'eps2c'; % 'eps2c'; 'png';
    
    fc_main_04_get_filter_plot_maxima(path_all_data_folder, all_data_folder,...
        folder_filter, parameters_search, flag_fig, labels, fig_format);
end
%% ============
if mains(5) == 1
    folder_filter = {'lote'};
    total_colors = 5; % Input
    
    % report_PATH = '../Relatorio/';
    % flag_TeX0_Word1 = 0; % 0 1

    % report_PATH = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/Doc_Tables';
    % report_PATH = '../Doc_Tables';
    report_PATH = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_video/Relatorio';
    flag_TeX0_Word1 = 1; % 0 1

    file_sufix_name = 'results_min_max_00';
    new_label_MSWord = 'Tabela';

    fc_main_05_table_creation(path_all_data_folder, all_data_folder,...
        folder_filter, total_colors, report_PATH, file_sufix_name, ...
        flag_TeX0_Word1, new_label_MSWord);
end
%% ============
if mains(6) == 1

    folder_filter = {'lote'};

    escala = 10;
    % escala = 100;

    % labels = {'D�cimo de minuto','Intensidade Relativa'};
    % labels = {'Cent�simo de minuto','Intensidade Relativa'};

    data_limit = 700;
    fc_main_06_table_to_pca(path_all_data_folder, all_data_folder,...
        folder_filter, escala, data_limit);
end
%% ============
if mains(7) == 1
    folder_filter = {'lote'};
    
    % new_fig_folder = '../data_for_analysis/pasta_lote00/figures_with_maximum';
    % report_PATH = '../Relatorio/';
    
    report_PATH = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_video/Relatorio';
    
%     new_fig_folder = 'figures_with_maximum';
%     file_fig_sufix_name = 'espectro';

    new_fig_folder = 'Figures_Comparing_Samples';
    file_fig_sufix_name = 'comparacoes';
    
    extension = {'.png'};
    % name_filter = {'f4'};
    name_filter = {'fig'};

    new_label_MSWord = 'Figura';
    flag_none_up_dw = 1;
    report_title_Word = 'Relat�rio: Figuras.';
    % report_title_Word = 'Report: Figures.';
    
    % flag_TeX0_Word1 = 0;
    % flag_TeX0_Word1 = 1;
    
    for flag_TeX0_Word1 = [0,1]
        fc_main_07_automatic_insert_fig_specter(path_all_data_folder,...
            all_data_folder,folder_filter, new_fig_folder, file_fig_sufix_name,...
            extension, name_filter, report_PATH, flag_TeX0_Word1, new_label_MSWord, ...
            flag_none_up_dw, report_title_Word);
    end
end
%% ============ 8a
if mains(8) == 1
    folder_filter = {'lote'};
    %folder_filter = {'lote10'};
    %folder_filter = {'lote09','lote10'};

    filtered_mat_folder = 'filtered_mat';
    new_fig_max_folder = 'figures_with_maximum';
    file_all_data = 'data_all_M_filtered.mat';

    file_to_load_name = 'tab_mat_cell';
    decimal = {'%0.1f','%0.1f'};
    fc_main_08_a_table_creation(path_all_data_folder, all_data_folder,...
        folder_filter, filtered_mat_folder, new_fig_max_folder, file_all_data, ...
        file_to_load_name, decimal);

end
%% ============ 8b
if mains(9) == 1
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};
    % folder_filter = {'lote09','lote10'};

    filtered_mat_folder = 'filtered_mat';
    file_to_load_name = 'tab_mat_cell';
    dot0_comma1 = 1;

    fc_main_08_b_table_format(path_all_data_folder, all_data_folder,...
        folder_filter, filtered_mat_folder, file_to_load_name, dot0_comma1);
end
%% ============ 9a
if mains(10) == 1
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};
    %folder_filter = {'lote09','lote10'};

    filtered_mat_folder = 'filtered_mat';
    file_to_load_name = 'tab_mat_cell';

    % flag_TeX0_Word1 = 0;
    % caption_name = 'Tabela com os resultados de todos os lotes -- ordenados por tempo de reten��o.';

    % tex_file_name_path = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/Relatorio';
    tex_file_name_path = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_video/Relatorio';
    tex_tab_name_1_sufix = 'results_t_min_max';

    tex_file = {tex_file_name_path, tex_tab_name_1_sufix};

    % tex_radical = 'input_longtab';
    tex_radical = 'input_tab';

    filter = {'t_min_max'};
    dot0_comma1 = 1;

    table_folder = 'Tabelas';

    fc_main_09_a_table_file_LaTeX(path_all_data_folder, all_data_folder,...
        folder_filter, filtered_mat_folder, file_to_load_name,...
        tex_file_name_path, table_folder, tex_file, tex_radical, ...
        filter, dot0_comma1);
end
%% ============ 9b
if mains(11) == 1
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};
    
    filtered_mat_folder = 'filtered_mat';
    file_to_load_name = 'tab_mat_cell';

    TitleStyleName = 'T�tulo 1'; % Change for your language Title.
    TableString = ' Gerada automaticamente pelo Matlab';
    LegendStyleName = 'Legenda'; % Check your language for Legend.
    new_label = 'Tabela';
    separator = ' -';

    TableCaptions = {TitleStyleName, TableString, LegendStyleName,...
        new_label, separator};

    % DocReport_folder = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/Doc_Results_Tables';
    DocReport_folder = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_video/Relatorio';
    DocName_base = 'tabelas_t_min_max';

    fc_main_09_b_table_file_MSWord(path_all_data_folder, all_data_folder,...
        folder_filter, filtered_mat_folder, file_to_load_name,...
        DocReport_folder, DocName_base, TableCaptions);
end
%% ============ 9c
if mains(12) == 1
    % folder_filter = {'lote'};
    folder_filter = {'lote15'};
    
    filtered_mat_folder = 'filtered_mat';
    file_to_load_name = 'tab_mat_cell';

    % XlsReport_folder = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/Xls_Results_Tables';
    XlsReport_folder = 'C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_video/Relatorio';
    XlsName_base = 'tabelas_t_min_max';

    fc_main_09_c_table_file_MSExcel(path_all_data_folder, all_data_folder,...
        folder_filter, filtered_mat_folder, file_to_load_name,...
        XlsReport_folder, XlsName_base);
end
%% ============
toc
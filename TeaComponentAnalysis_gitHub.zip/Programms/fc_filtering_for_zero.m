function M = fc_filtering_for_zero(M,value)
for k = 1:size(M)
    if M(k,3) < value
        M(k,3) = 0;
    end
end
end
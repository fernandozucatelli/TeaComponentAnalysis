%% fc_main_02_matrix_filtering
%%%%%%%%%%%%%
% help fc_main_02_matrix_filtering
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to create a single cell with all matrices after filtering small
%   values
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% version 01: 01.12.2019 -- Creation
%   Some details of this version
%   The numbers are in the "%02d" format and separate with colon ":"
%   Each version must have the date in the format dd.mm.yyyy
% version 02: 04.12.2019 -- Renamed from: script_mat_analysis
%   to: fc_main_02_matrix_filtering
%   This version adds the folders_list level of complexity.
%       The operations are performed of every file in every folder.
% version 03: 10.12.2019 -- variables 'M' and 'value_filter' have been
%       added to all_M_filtered
% version 04: 2020-02-13 -- Revision with Roberta
%   all_data_folder = 'data_for_analysis'; % Input -- main 01
%%%%%%%%%%%%%
%% algorithm
function fc_main_02_matrix_filtering(path_all_data_folder, all_data_folder,...
    value_filter, folder_filter)
%% Parameters
num_colums_M_filtered = length(value_filter) + 6; % M filtros file_name cor sabor marca estado
%% Naming of all inside folders
new_mat_folder = 'only_data_mat';
filtered_M_folder = 'filtered_mat';
programms_folder = pwd;
%% Fixed filters
mat_filter = {'.mat'};
%% Name of the file
filtered_M_file = 'data_all_M_filtered';
%% Load all txt file of a folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Loop for all folders
fprintf('Iniciado - Start\n');
for j = 1:length(folders_list)
    %% Go to the folder
    folder = char(folders_list(j));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    cd(go_to_folder);
    %% creating folders to store new files
    if ~exist(filtered_M_folder, 'dir'); mkdir(filtered_M_folder); end
    %% Jump to mat folder
    cd(new_mat_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,mat_filter);
    cd('../');
    all_M_filtered = cell(length(filelist),num_colums_M_filtered);
    %% main loop
    for k = 1:length(filelist)
        %% Carregar para os análise
        file_name = sprintf('%s/%s', new_mat_folder, char(filelist(k)));
        load(file_name);
        all_M_filtered{k,1} = M; % M is loaded from file_name
        for f = 1:length(value_filter)
            M_filtered = M(M(:,3) >= value_filter(f),:);
            all_M_filtered{k,f+1} = M_filtered;
        end
        all_M_filtered{k,f+2} = file_name;
        all_M_filtered{k,f+3} = cor;
        all_M_filtered{k,f+4} = sabor;
        all_M_filtered{k,f+5} = marca;
        all_M_filtered{k,f+6} = estado;
    end
    save_name = sprintf('%s/%s.mat', filtered_M_folder, filtered_M_file);
    save(save_name,'all_M_filtered','value_filter');
end
%% Come back to main folder
cd(programms_folder);
fprintf('Conclu�do - Finished\n');
toc
end
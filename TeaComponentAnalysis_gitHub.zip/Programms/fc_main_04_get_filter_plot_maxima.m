%% fc_main_04_get_filter_plot_maxima
%%%%%%%%%%%%%
% help fc_main_04_get_filter_plot_maxima
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to create each individual plot identifying a set of maximum
%   peaks away epsilon from each other
%%%%%%%%%%%%%
% flag_fig -- determines behavior and types of graph to be plotted
% 0: No figures saved
% 1: Intensity order -- filtered out
% 2: Intensity order -- filtered to 0
% 3: Temporal order -- filtered out
% 4: Temporal order -- filtered to 0
% 5: All figures
%%%%%%%%%%%%%
% value_filter: loaded from the .mat file
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%% From sort library
% fc_lib_sort_search_filtering_pts_dist_eps
%%%%%%%%%%%%%
% version 01: 08.12.2019 -- Creation
% version 02: 10.12.2019 -- Simplifying search after update on main_02
%   Rename from "main_05_..." to "main_04..." because the old main_04 is
%       dependent of the results of this script.
%   Updated to receive data directly from "data_all_M_filtered.mat"
%   Create all_coordenadas_cell with all found points
% version 03: 2020-02-13 -- Revision with Roberta
% version 04: 2021-11-24 -- Added fig_format option
%%%%%%%%%%%%%
%% algorithm
function fc_main_04_get_filter_plot_maxima(path_all_data_folder, all_data_folder,...
    folder_filter, parameters_search, flag_fig, labels, fig_format)
%% Parameters % Input
pts_searched = parameters_search(1);
epsilon = parameters_search(2);
passo = parameters_search(3);
%% Folders
filtered_mat_folder = 'filtered_mat';
new_fig_max_folder = 'figures_with_maximum'; % Input
file_all_data = 'data_all_M_filtered.mat';
programms_folder = pwd;
%% Go to the folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
cd(programms_folder);
%% Loop for all folders
fprintf('Iniciado - Start\n');
for j = 1:length(folders_list)
    %% Load data_all_M_filtered
    folder = char(folders_list(j));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    load_name = sprintf('%s/%s/%s', go_to_folder, filtered_mat_folder,file_all_data);
    load(load_name);
    %% Creating folders to store new files
    fig_save_path = sprintf('%s/%s',go_to_folder,new_fig_max_folder);
    if ~exist(fig_save_path,'dir'); mkdir(fig_save_path); end
    %% Evitar repetir figuras j� feitas
    L = size(all_M_filtered,1); % loaded from external file
    V = length(value_filter);
    all_coordenadas_cell = cell(L,V+1);
    for k = 1:L
        dados = all_M_filtered(k,:);
        %% Call graph function
        all_coordenadas_cell(k,1:V) = fc_graph_maximum_points_epsilon(dados, value_filter, ...
            pts_searched, epsilon, passo, fig_save_path, flag_fig, labels, fig_format);
        all_coordenadas_cell{k,V+1} = all_M_filtered{k,V+3};
        close all;
    end
    save_name = sprintf('%s/all_pts_max_%s.mat', fig_save_path, folder);
    save(save_name,'all_coordenadas_cell');
end
fprintf('Conclu�do - Finished\n');
end
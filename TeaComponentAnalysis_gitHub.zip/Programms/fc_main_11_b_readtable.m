%% fc_main_11_b_readtable
%%%%%%%%%%%%%
% help fc_main_11_b_readtable
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to extract data from a excel spreadsheet through the command
%   readtable
%%%%%%%%%%%%%
% This is not a good funcion and is not finished
%%%%%%%%%%%%%
%% Load all .xls and .xslx with readtable
% 'Format','%.3f %.3f %.3f %d %.2f %d %.2f %.2f %.2f %s %d %s %d %s'
% T = readtable(filename);
% T = readcell(filename);
% T = readmatrix(filename);
%%%%%%%%%%%%%
% version 01: 2020-01-01 -- Creation (ISO8601)
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_11_b_readtable(excel_data_folder, ord)
%% Naming of all inside folders
programms_folder = pwd;
%% Go to folder
cd(excel_data_folder);
%% Load all .xls and .xslx spreadsheets and converting them into .mat files
extension = {'.xlsx'};
filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,extension);
%%
for k = 1:length(filelist)
    filename = char(filelist(k));
    T = readtable(filename);
    if k == 1
        T_new = T(:,ord);
    else
        T_new.Nome = [T_new.Nome, T.Nome];
        T_new.Prob = [T_new.Prob, T.Prob];
        T_new.x__rea = [T_new.x__rea, T.x__rea];
        T_new.TempoDeReten__o = [T_new.TempoDeReten__o, T.TempoDeReten__o];
    end
end
disp(T_new);
%% Return to Programms folder
cd(programms_folder);
end
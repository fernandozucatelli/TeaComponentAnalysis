%% fc_main_08_b_table_format
%%%%%%%%%%%%%
% help fc_main_08_b_table_format
% Belongs to private library
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Function to prepare headers for table in LaTeX and MSWord
%%%%%%%%%%%%%
% version 01: 2020-03-01 -- Creation (ISO8601)
% version 02: 2020-03-10 -- Removing "%s/%s" that added retention time
%   copies. This feature applies to Molecular Mass, but is redundant for
%   retention time.
% version 03: 2021-11-24 -- Added dot0_comma1 to choose decimal separator
%%%%%%%%%%%%%
%% algorithm
function fc_main_08_b_table_format(path_all_data_folder, all_data_folder,...
    folder_filter, filtered_mat_folder, file_to_load_name, dot0_comma1)
%% Programm folders
programms_folder = pwd;
%% Load folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% main
for q = 1:length(folders_list)
    folder = char(folders_list(q));
    go_to_folder = sprintf('%s/%s/%s/%s',path_all_data_folder,all_data_folder, ...
        folder, filtered_mat_folder);
    cd(go_to_folder);
    filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,{file_to_load_name});
    filelist = filelist(~contains(filelist,'style'));
    for p = 1:length(filelist)
        load_name = char(filelist(p));
        load(load_name);
        %% Parameters
        linhas = size(new_super_tab,1);
        pos_amostra = 6;
        n_base_col = 1;
        t_med_col = 1;
        col_per_amostra = 3;
        %% Table as cell
        base_tab_cell = cell(linhas,n_base_col + col_per_amostra*n_amostras);
        %% main
        % j: counter of the new table; r: counter of repetitions
        j = 1;
        for k = 1:linhas
            if k >= 2 && strcmp(new_super_tab{k,t_med_col},new_super_tab{k-1,t_med_col})
                j = j - 1;
            end
            base_tab_cell(k,:) = {'--'};
            pos = 1;
            amostra = new_super_tab(k,pos_amostra);
            while pos <= n_amostras && ~strcmp(amostras_name{pos}, amostra)
                pos = pos + 1;
                %amostra = new_super_tab(k,pos_amostra); % exp_cell{pos}{1}(1:end-5);
            end
            if strcmp(char(base_tab_cell(j,1)),'--')
                base_tab_cell(j,n_base_col) = new_super_tab(k,n_base_col);
            end
            ord = [2,3,5];
            vec = n_base_col + col_per_amostra*(pos-1) + 1:n_base_col + col_per_amostra*pos;
            base_tab_cell(j,vec) = new_super_tab(k,ord);
            j = j + 1;
        end
        %% Screen and remotion of extra cells
        base_tab_cell = base_tab_cell(1:j-1,:);
        %% Headers
        base_header = {'min','max','h'};
        sample_header = cell(1,n_base_col + n_amostras);
        sample_header(n_base_col) = {' '};
        sample_word_header = cell(1,n_base_col + col_per_amostra*n_amostras);
        sample_word_header(n_base_col) = {' '};
        repeated_header = cell(1,n_base_col + col_per_amostra*n_amostras);
        repeated_header(n_base_col) = {'t'};
        for pos = 1:n_amostras
            amostra = amostras_name{pos};
            sample_header{n_base_col + pos} = sprintf('\\multicolumn{%d}{c}{%s}',...
                col_per_amostra, amostra);
            vec = n_base_col + col_per_amostra*(pos-1) + 1:n_base_col + col_per_amostra*pos;
            sample_word_header(vec) = [{amostra}, {''}, {''}];
            repeated_header(vec) = base_header;
        end
        %% Adapting to MSWord and MSExcel
        repeated_header = strrep(repeated_header,'_{',' ');
        repeated_header = strrep(repeated_header,'}','');
        base_tab_cell_header = [sample_word_header; repeated_header; base_tab_cell];
        vec = zeros(n_amostras,2);
        for pos = 1:n_amostras
            vec(pos,:)  = [n_base_col + col_per_amostra*(pos-1) + 1,n_base_col + col_per_amostra*pos];
        end
        colMerge = {1, vec};
        if dot0_comma1 == 1
            [NoRows,NoCols] = size(base_tab_cell_header);
            for i = 3:NoRows
                for j = 1:NoCols
                    base_tab_cell_header(i,j) = ...
                        {fc_lib_latex_ponto_para_virgula(char(base_tab_cell_header(i,j)),',')};
                end
            end
        end
        %% save style
        save_name_style = strrep(load_name,'.mat','_style.mat');
        save(save_name_style,'base_tab_cell_header','base_tab_cell','base_header','sample_header',...
            'sample_word_header','repeated_header','colMerge','n_base_col','col_per_amostra');
    end
end
%% Return to Programms folder
cd(programms_folder);
end
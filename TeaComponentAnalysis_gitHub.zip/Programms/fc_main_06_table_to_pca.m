%% fc_main_06_table_to_pca
%%%%%%%%%%%%%
% help fc_main_06_table_to_pca
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to prepare the data to the pca analysis
%%%%%%%%%%%%%
% version 01: 09.12.2019 -- Creation
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
% version 03: 2020-02-28 -- Update to finish format to toolbox for each
%   filter value, including no filtered.
%%%%%%%%%%%%%
%% algorithm
function fc_main_06_table_to_pca(path_all_data_folder, all_data_folder,...
    folder_filter, escala, data_limit)
%% Folders
filtered_mat_folder = 'filtered_mat';
file_all_data = 'data_all_M_filtered.mat';
programms_folder = pwd;
pca_folder_data = 'pca_matrix';
pca_file_name = 'pca_dados';
%% Go to the folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Loop for all folders
fprintf('Iniciado - Start\n');
for j = 1:length(folders_list)
    %% Load data_all_M_filtered
    folder = char(folders_list(j));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    load_name = sprintf('%s/%s/%s', go_to_folder, filtered_mat_folder,file_all_data);
    load(load_name);
    %% create pca
    pca_folder = sprintf('%s/%s',go_to_folder,pca_folder_data);
    if ~exist(pca_folder, 'dir'); mkdir(pca_folder); end
    %%
    for f = 1:(length(value_filter)+1)
        %% Rascunho -- Constru��o dados tal como positivo
        dados_rows = 0;
        for k = 1:size(all_M_filtered,1)
            x = size(all_M_filtered{k,f},1);
            if x > dados_rows
                dados_rows = x;
            end
        end
        qtde_experimento = size(all_M_filtered,1);
        dados = zeros(escala*dados_rows,qtde_experimento);
        for k = 1:size(all_M_filtered,1)
            x = all_M_filtered{k,f}; % valor n�o filtrado
            y = escala*x(:,1);
            z = round(y,0);
            dados(z,k) = x(:,3);
        end
        data_limit = min(data_limit,size(dados,1));
        dados = dados(1:data_limit,:)';
        if f == 1
            pca_data_lote_file = sprintf('%s/%s_filter_00.mat',pca_folder,pca_file_name);
        else
            pca_data_lote_file = sprintf('%s/%s_filter_%02d.mat',pca_folder,...
                pca_file_name, value_filter(f-1));
        end
        save(pca_data_lote_file, 'dados');
    end
    %% Finish and return
    fprintf('Conclu�do - Finished\n');
    cd(programms_folder);
end
%%
% x_lim = 7*10^2;
% plot(dados(1:x_lim,:)); % plot(dados);
% xlabel(char(labels{1}));
% ylabel(char(labels{2}));
%%
% P = pca(dados);
% plot(P(:,1:3));
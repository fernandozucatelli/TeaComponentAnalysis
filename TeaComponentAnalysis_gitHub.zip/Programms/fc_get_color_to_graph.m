function farbe = fc_get_color_to_graph(cor)
switch cor
    case 'AM'; farbe = [0.6 0.6 0]; % Dark Yellow
    case 'BR'; farbe = 'b'; % "Branco" "Cinza": 0.4*[1 1 1]; 'b'
    case 'VD'; farbe = [0 0.5 0]; % Dark Green
    case 'PR'; farbe = 'k';
    case 'VM'; farbe = 'r';
    otherwise; error('"cor" is not defined');
end
end
%% fc_main_07_automatic_insert_fig_specter
%%%%%%%%%%%%%
% help fc_main_07_automatic_insert_fig_specter
%%%%%%%%%%%%%
% Author: M.Eng. Fernando Henrique G. Zucatelli (UFABC)
% e-mail: fernandozucatelli@yahoo.com.br
% Chem. Roberta Kelly Nogueira (UFMG -- ICEX)
% e-mail: robertakm@ufmg.br
% COPYRIGHT: Free for non evil use. (N�o use este c�digo para o mal)
%%%%%%%%%%%%%
% Script to create the input of all figures from lote00
%%%%%%%%%%%%%
% Source: fhz (2019). File Manipulation Library
% (https://www.mathworks.com/matlabcentral/fileexchange/71864-file-manipulation-library),
% MATLAB Central File Exchange. Retrieved November 30, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_createFile_AllFilesName
%     fc_lib_allFilesName_to_ListOfFiles
%     fc_lib_ListOfFiles_filter
%%%%%%%%%%%%%
% Source: fhz (2019). Matlab to LaTeX Library
% (https://www.mathworks.com/matlabcentral/fileexchange/72155-matlab-to-latex-library),
% MATLAB Central File Exchange. Retrieved December 10, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_latex_fig_insert
%     fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     fc_lib_latex_fig_block_generator
%     fc_lib_save_file_extensao -> save_file_tex -- file_library
%%%%%%%%%%%%%
% Source: fhz (2019). Search and Replace a WordSet Library
% (https://www.mathworks.com/matlabcentral/fileexchange/61226-search-and-replace-a-wordset-library),
% MATLAB Central File Exchange. Retrieved December 10, 2019.
%%%%%%%%%%%%% From Source
% fc_lib_file_search_replace_wordset
%     fc_lib_createFile_AllFilesName_ListOfFiles_filter
%     % and This function calls:
%       fc_lib_createFile_AllFilesName
%       fc_lib_allFilesName_to_ListOfFiles
%       fc_lib_ListOfFiles_filter
%     fc_lib_file_locsub_arquivos
%%%%%%%%%%%%%
% version 01: 09.12.2019 -- Creation
% version 02: 2020-02-13 -- Revision with Roberta
%   New robust folder navigation
%   Transformation into function design instead of script design.
%%%%%%%%%%%%%
%% algorithm
function fc_main_07_automatic_insert_fig_specter(path_all_data_folder,...
    all_data_folder,folder_filter,new_fig_folder, file_fig_sufix_name,...
    extension, name_filter, report_PATH, flag_TeX0_Word1, new_label_MSWord,...
    flag_none_up_dw, report_title_Word)
%% Naming of all inside folders
programms_folder = pwd;
if ~exist(report_PATH,'dir'); mkdir(report_PATH); end
%% Load all txt file of a folder
cd(path_all_data_folder); cd(all_data_folder);
folders_list = fc_lib_createFile_AllFoldersName_ListOfFiles_filter(pwd,0,0,folder_filter);
%% Loop for all folders
for j = 1:length(folders_list)
    %% Go to folder with figures maximum points
	folder = char(folders_list(j));
    go_to_folder = sprintf('%s/%s/%s',path_all_data_folder,all_data_folder, folder);
    cd(go_to_folder); cd(new_fig_folder);
    %% Creating file with figures for LaTeX or Word
    if flag_TeX0_Word1 == 0
        flag_PATH = 1;
        texfilename = sprintf('%s/%s_%s',report_PATH,'input_fig',file_fig_sufix_name);
        linewidth = 0.8;
        lv_up = 0;
        %% Automatic caption list from filtered filelist
        caption_list = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,name_filter);
        for k = 1:length(caption_list)
            caption_list(k) = {strrep(caption_list{k}(1:end-4),'_', ' ')};
        end
        %% Gera��o do arquivo de figuras
        fc_lib_latex_fig_insert(pwd,flag_PATH,extension,lv_up,caption_list,texfilename,name_filter,linewidth,3,2);
    else
        %% Name of doc file, go to folder and list of figures and captions
        word_file_name = sprintf('%s_%s.doc','input_fig_word',file_fig_sufix_name);
        if contains(report_PATH,'..') == 1
            cd('..');
            report_PATH = sprintf('%s/%s',pwd,report_PATH(3:end));
        end
        filelist = fc_lib_createFile_AllFilesName_ListOfFiles_filter(pwd,0,0,name_filter);
        caption_list = filelist;
        for k = 1:length(caption_list)
            caption_list(k) = {strrep(caption_list{k}(1:end-4),'_', ' ')};
        end
        %% Creating file and title
        FileSpec = fullfile(report_PATH,word_file_name);
        [ActXWord,WordHandle] = fc_lib_msword_start_Word(FileSpec,0);
        fc_lib_msword_write_text(ActXWord,report_title_Word,'Normal',[0,1],1);
        %% Parameters and command
        align = 1; % center;
        WHK = []; % Use original dimensions
        fc_lib_msword_allfigures_into_Word_caption(ActXWord,filelist,align,...
            caption_list,WHK,flag_none_up_dw,new_label_MSWord);
        %% Extra paragraph after figures
        for n = 1:2
            ActXWord.Selection.TypeParagraph;
        end
        fc_lib_msword_close_Word(ActXWord,WordHandle,FileSpec);
    end
end
%% Return to the programms folder
cd(programms_folder);
end
%% Corre��o do endere�o das figuras
% cd(report_PATH);
% filter = {'input_fig'};
% input = {'../figures_with_maximum/',...
%     '\label{C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_analysis/pasta_lote00/figures_with_maximum/',...
%     'ref{C:/Users/FHZ/Dropbox/Projeto_Roberta_Nogueira_Matlab/data_for_analysis/pasta_lote00/figures_with_maximum/'};
% output = {'../data_for_analysis/pasta_lote00/figures_with_maximum/',...
%     '\label{fig:',...
%     'ref{fig:'};
% encod = 'ISO-8859-1';
% flag_copy = 0;
% fc_lib_file_search_replace_wordset(pwd,filter,input,output,flag_copy,encod);